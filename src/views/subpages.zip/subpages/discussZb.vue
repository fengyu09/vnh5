<template>
  <div id="discuss">
    <x-header
      style="background-color:transparent;z-index: 1001;color:#000"
      :left-options="{showBack: false}"
    >
      <span style="color: #000000;">评论</span>
      <i class="black-back"></i>
      <div
        style="position:absolute;width:42px;height:42px;top:0;left:0; z-index: 10000001;"
        @click="goBack()"
      ></div>
    </x-header>
    <!-- :isLoad="isL"
		v-on:func="reLoad"
		:isUp="isUpFlag"
    :isloadUp="isLup"-->
    <myScroll
      ref="scrollWrapper"
      :isUp="isUpFlag"
      :isloadUp="isLup"
      v-on:func="reLoad"
      :isDown="true"
      :isLoad="isL"
      :bottom="1.38"
    >
      <div class="main">
        <div style="padding: 10px 0.3rem 0 0.3rem;">
          <div
            class="head"
            style="display: flex;align-items: center;position:relative;"
            @click="getInfo1(artInfo)"
          >
            <img
              :src="artInfo.avatar"
              alt
              style="width: 50px;height: 50px;border-radius: 50%;z-index: 1;"
            />
            <div :class="artInfo.live_status==1 ? 'circle1' : ''"></div>
            <div :class="artInfo.live_status==1 ? 'circle1' : ''"></div>
            <div :class="artInfo.live_status==1 ? 'circle1' : ''"></div>
            <div style="margin-left: 0.25rem;">
              <p style="font-size: 0.37rem;">{{artInfo.nickname}}</p>
              <p style="color: #cccccc;margin-top: 0.1rem;">{{artInfo.create_time | formatDate1}}</p>
            </div>
          </div>
          <div style="font-size: 0.38rem;padding:0.2rem 0;">
            <span>{{artInfo.text}}</span>
          </div>
          <div class="imgbox">
            <div class="img-item" v-for="(item,index) in artInfo.media" :key="index">
              <img v-lazy="item" preview="99" alt />
            </div>
          </div>
        </div>
        <div class="cut-box"></div>
        <div class="pl-box">
          <p class="pl-num">
            评论
            <span style="color: #999999;">({{plnum}})</span>
          </p>
          <div
            class="pl-content"
            :id="item.id"
            v-for="(item,index) in plList"
            :key="index"
            :ref="item.id"
          >
            <!-- <span ref="topHeight" style="display:none">{{item.id}}</span> -->
            <div
              style="width:46px;height:46px"
              @click="getInfo(item.uid,item.user_type)"
            >
              <img class="pl-tx" :src="item.avatar" alt />
            </div>
            <div class="right-content">
              <p class="pl-name">
                {{item.nickname}}
                <i class="zb-icon" v-if="item.isanchor==true">主播</i>
              </p>

              <p class="text1" v-html="item.content"></p>
              <div class="pl-time">
                <span style="color: #ccc;">{{item.created}}</span>
                <div class="huifu" @click="huifu(item.pid,item.nickname,item.comment_id,item.uid)">
                  <i class="huifu-icon"></i> 回复
                </div>
                <!-- likesafter -->
                <div
                  :class="{like:true,likesafter:item.is_like}"
                  @click="dolikes(item.comment_id,index)"
                >
                  <i class="like-iocn"></i>
                  {{item.like}}
                </div>
              </div>
              <div class="huifu-box" v-if="item.reply.length">
                <p class="firsthf" v-for="(item1,index1) in item.reply" :key="index1">
                  <span class="name">
                    <i class="zb-icon" v-if="item1.isanchor==true">主播</i>
                    <i @click="getInfo(item1.uid,item1.user_type)">{{item1.nickname}}</i>
                    <a style="color:#333333" v-if="item.uid!=item1.p_uid">回复</a>
                    <i
                      class="zb-icon"
                      v-if="item1.p_user_type==2&&item.nickname!=item1.p_nickname"
                    >主播</i>
                    <i
                      @click="getInfo(item1.p_uid,item1.p_user_type)"
                      v-if="item.nickname!=item1.p_nickname"
                    >{{item1.p_nickname}}</i>
                  </span>：
                  <span
                    class="hf-text"
                    v-html="item1.content"
                    @click="huifu(item1.pid,item1.nickname,item1.comment_id,item1.uid)"
                  ></span>
                  <!-- <div v-if="item1.reply" class="secondhf">
                    <p v-for="(item2,index2) in item1.reply" :key="index2">
                      <span class="name">
                        <i class="zb" v-if="item2.isanchor==true">主播</i>
                        {{item2.nickname}}
                      </span> 回复
                      <span class="name">
                        <i class="zb" v-if="item1.isanchor==true">主播</i>
                        {{item2.p_nickname}}
                      </span>
                      <a class="content"  @click="dthf(item2.id,item2.nickname,item2.user_id,2)">{{item2.content}}</a>
                    </p>
                  </div>-->
                </p>
                <!-- <p><i class="zb-icon">主播</i><span class="name">派大星</span> <span>回复</span> <i class="lz-icon">楼主</i><span class="name">大猫</span>：<span>可以，可以</span></p> -->
              </div>
            </div>
          </div>
        </div>
        <p style="text-align: center;padding: 0.3rem 0;" v-if="deadline">我也是有底线的~</p>
      </div>
    </myScroll>
    <!-- iptBottom -->
    <div class="pl-input" :style="{bottom:iptBottom}">
      <div @click="vmeClick">
        <keep-alive>
        <vme ref="vmeChild" v-show="showEmj" style="bottom: 1.3rem;z-index: 1448;"></vme>
      </keep-alive>
      </div>
     
      <div class="input-bg">
        <!-- @keypress="plSubmit" -->
        <input
          v-model="chatMsgForm.comment_text"
          type="text"
          ref="huiipt"
          id="textInput"
          @focus="iptFocus"
          placeholder="要对他说点什么吗"
        />
        <div class="emoj-icon" @click="emojShow"></div>
      </div>
      <!-- <div>
				<i class="like-iocn"></i><span>867</span>
      </div>-->
      <div class="sendbtn" @click="plSubmit">
        <span>发送</span>
      </div>
    </div>

    <x-dialog v-model="dialogShow" hide-on-blur @on-hide="showEmj=false;hfId='';iptBottom='0'"></x-dialog>

    <div class="successPop" v-if="success">
      <div class="bgPop"></div>
      <div class="content">
        <img src="../../assets/images/fbcg.png" alt />
        <span class="span1">发布成功</span>
        <span class="span2">小姐姐正在努力审核中</span>
      </div>
    </div>
  </div>
  
</template>
<script>
import myScroll from "../../components/myScroll.vue";
import vme from "../../components/vue-mobile-emoji/vme.vue";
import { mapMutations, mapState } from "vuex";
import { XDialog } from "vux";
export default {
  name: "discuss",
  components: {
    myScroll,
    XDialog,
    vme
  },
  computed: {
    ...mapState(["codeToken", "userinfo", "username", "avatar"])
  },

  data() {
    return {
      success: false,
      artInfo: {},
      plText: "",
      dialogShow: false,
      isLup: false,
      plnum: "",
      plList: [],
      chatMsgForm: {
        comment_text: ""
      },
      showEmj: false,
      hfId: "",
      hfname: "",
      hfperson: "",
      isMore: true,
      isUpFlag: true,
      page: 1,
      deadline: false,
      isL: false,
      iptBottom: 0,
      type: 1,
      hf: false,
      winHeight:window.innerHeight
    };
  },
  watch: {
    chatMsgForm: function(n) {
      this.$nextTick(() => {
        this.chatMsgForm.comment_text = n.replace(
          /[\uD83C|\uD83D|\uD83E][\uDC00-\uDFFF][\u200D|\uFE0F]|[\uD83C|\uD83D|\uD83E][\uDC00-\uDFFF]|[0-9|*|#]\uFE0F\u20E3|[0-9|#]\u20E3|[\u203C-\u3299]\uFE0F\u200D|[\u203C-\u3299]\uFE0F|[\u2122-\u2B55]|\u303D|[\A9|\AE]\u3030|\uA9|\uAE|\u3030/gi,
          ""
        );
      });
    }
  },
  created() {
    this.onlyThisNotice();
    this.getplList();
    window.onresize = function() {
      if(this.winHeight>window.innerHeight){
        // this.iptBottom=(this.winHeight-window.innerHeight-200)+'px'
      }
    }.bind(this);
  },
  mounted() {
    this.$previewRefresh();
  },
  methods: {
    onlyThisNotice() {
      //  this.artInfo = JSON.parse(localStorage.getItem("zbpl"));

      let zb = JSON.parse(localStorage.getItem("zbpl"));

      this.$http
        .get(this.versionLive2+"live/get_dynamic/", {
          params: {
            user_id: this.$store.state.userinfo.user_id,
            dynamic_id: zb.dynamic_id,
            msg_id: zb.comment_id
          }
        })
        .then(res => {
          // this.artInfo =res.data.data
          this.artInfo = {
            avatar: res.data.data[0].avatar,
            nickname: res.data.data[0].nickname,
            create_time: res.data.data[0].create_time,
            text: res.data.data[0].text,
            media: res.data.data[0].media,
            id: res.data.data[0].dynamic_id,
            live_status: res.data.data[0].live_status
          };
          console.log(this.artInfo);
          this.getplList();
          // localStorage.setItem('zbpl',JSON.stringify(""))
        });
      // } else {
      //   this.artInfo = JSON.parse(localStorage.getItem("zbpl"));
      //   console.log(this.artInfo);
      // }

      // var h =
      //   document.documentElement.clientHeight || document.body.clientHeight;

      // console.log(h - 80);
      //   }
    },
    plSubmit(e) {
      if (
        // 判断是否登录如果登录
        this.$store.state.userinfo.user_id == "" ||
        this.$store.state.userinfo.user_id == undefined
      ) {
        // 如果没有登录提示请登录
        this.$popup({
          title: "我是标题",
          content: "我是内容",
          btnText: "我是按钮",
          click: () => {
            this.isLogin = false;
          }
        });
        return;
      }
      if (this.chatMsgForm.comment_text != "") {
        this.success = true;
        this.$refs.huiipt.blur();
        this.dialogShow = false;
        this.$vux.loading.show();
        this.showEmj = false;
        if (this.hf == false) {
          // this.chatMsgForm.comment_text='';
          this.$http
            .post(this.versionLive2+"live/dynamic_comment/", {
              dynamic_id: this.artInfo.id,
              user_id: this.userinfo.user_id,
              nickname: this.username,
              comment_text: this.chatMsgForm.comment_text
              //   avatar: this.avatar.slice(this.avatar.indexOf("a"))
            })
            .then(res => {
              this.$vux.loading.hide();
              if (res.data.code == 1) {
                setTimeout(() => {
                  this.success = false;
                }, 3000);
                // this.$vux.toast.text("评论成功,请耐心等待系统审核", "middle");
                // res.data.data.reply = [];
                // res.data.data.avatar = this.avatar;
                // this.plList.unshift(res.data.data);
                // this.flitImg(this.plList);
                // this.getplList();
                this.chatMsgForm.comment_text = "";
              }
            });
        } else if (this.hf == true) {
          let hfId = this.hfId;
          this.$http
            .post(this.versionLive2+"live/dynamic_comment/", {
              dynamic_id: this.artInfo.id,
              user_id: this.userinfo.user_id,
              nickname: this.hfname,
              comment_text: this.chatMsgForm.comment_text,
              comment_id: this.hfperson
              //   avatar: this.avatar.slice(this.avatar.indexOf("a"))
              // reply_user_id:this.hfperson,
              // reply_nickname:this.hfname
            })
            .then(res => {
              console.log(res);
              this.$vux.loading.hide();
              if (res.data.code == 1) {
                setTimeout(() => {
                  this.success = false;
                }, 3000);
                // this.$vux.toast.text("回复成功", "middle");
                // let fdindex = this.plList.findIndex(i => i.id == hfId);
                // this.plList[fdindex].reply.push({
                //   p_nickname: res.data.reply_nickname,
                //   nickname: this.username,
                //   content: this.chatMsgForm.comment_text
                // });
                // this.flitImg(this.plList);
                // // this.getplList();
                this.chatMsgForm.comment_text = "";
              }
            });
        }
      } else {
        this.$vux.toast.text("请输入内容", "middle");
        this.$refs.huiipt.focus();
      }
    },
    huifu(id, name, nameid, uid) {
      if (uid == this.$store.state.userinfo.user_id) {
        this.$vux.toast.text("请不要给自己回复", "middle");
        return;
      } else {
        this.hf = true;
        this.$refs.huiipt.focus();
        this.dialogShow = true;
        this.hfId = id;
        this.hfname = name;
        this.hfperson = nameid;
      }
    },
    // dthf(id, name, nameid, type) {
    //   this.type = 2;
    //   if (nameid == this.$store.state.userinfo.user_id) {
    //        this.$vux.toast.text("请不要给自己回复", "middle");
    //        return;
    //   } else {
    //     this.$refs.huiipt.focus();
    //     this.dialogShow = true;
    //     this.hfId = id;
    //     this.hfname = name;
    //     this.hfperson = nameid;
    //   }
    // },
    dolikes(i, index) {
      if (
        // 判断是否登录如果登录
        this.$store.state.userinfo.user_id == "" ||
        this.$store.state.userinfo.user_id == undefined
      ) {
        // 如果没有登录提示请登录
        this.$popup({
          title: "我是标题",
          content: "我是内容",
          btnText: "我是按钮",
          click: () => {
            this.isLogin = false;
          }
        });
        return;
      }
      this.$http
        .post(this.versionLive2+"live/dynamic_like/", {
          type: 2,
          like_id: i.toString(),
          user_id: this.$store.state.userinfo.user_id
        })
        .then(res => {
          if (res.data.code == 1) {
            if (res.data.data.is_like == true) {
              this.plList[index].like = parseInt(this.plList[index].like) + 1;
            } else {
              this.plList[index].like = parseInt(this.plList[index].like) - 1;
            }
            // this.plList[index].like = parseInt(this.plList[index].like) + 1;
          }
          //  else if (res.data.code == 0) {
          //   this.plList[index].like = parseInt(this.plList[index].like) - 1;
          // }
          this.plList[index].is_like = !this.plList[index].is_like;
        });
    },
    getInfo(id, type) {
      if (type == 1) {
        this.$router.push({ name: "userInfo", query: { id } }); //进入用户个人页
      } else if (type == 2) {
        this.$router.push("/anchorProfile/" + id); //进入主播个人页
      } else if (type == 3) {
        this.$router.push("/expertCenter/" + id); //进入专家个人页
      }
    },

    getInfo1(i) {
      //进入用户   主播个人页
      if (i.live_status == 1) {
        this.$router.push("/chat/" + i.anchor_id);
      } else {
        this.$router.push("/anchorProfile/" + i.anchor_id);
      }
    },
    reLoad(data) {
      if (data == "up") {
        // this.loadMore();
      } else if (data == "down") {
        // this.renovate()
      }
    },
    emojShow() {
      this.showEmj = !this.showEmj;
      this.$refs.huiipt.focus();
    },
	vmeClick(){
		this.$refs.huiipt.focus();
	},
    getplList() {
      this.$vux.loading.show();
      let id = "";
      if (this.artInfo.dynamic_id == undefined) {
        id = this.artInfo.msg_id;
      } else if (this.artInfo.msg_id == undefined) {
        id = this.artInfo.dynamic_id;
      } else {
        id = this.artInfo.id;
      }
      this.$http
        .get(this.versionLive2+"user/get_comment_list/", {
          params: {
            dym_id: this.artInfo.id,
            user_id: this.$store.state.userinfo.user_id,
            limit: 1000
          }
        })
        .then(res => {
          this.$vux.loading.hide();
          if (res.data.code == 1) {
            this.plnum = res.data.total;
            this.plList = res.data.data;
            this.flitImg(res.data.data);
          }
        });
    },

    flitImg(data) {
      let len = this.$refs.vmeChild.emojis.length;
      let fhbq = this.$refs.vmeChild.fhbqList;
      let dL = data.length;
      for (let o = 0; o < dL; o++) {
        for (let i = 0; i < len; i++) {
          if (data[o].content.indexOf(this.$refs.vmeChild.emojis[i]) > -1) {
            let len = data[o].content.length;
            for (let j = 0; j < len; j++) {
              this.plList[o].content = this.plList[o].content.replace(
                this.$refs.vmeChild.emojis[i],
                '<img src="../static/images/chat/emoji/' +
                  this.$refs.vmeChild._emojiName(
                    this.$refs.vmeChild.emojis[i]
                  ) +
                  '">'
              );
            }
          }
          if (data[o].reply.length) {
            for (let y = 0; y < data[o].reply.length; y++) {
              if (data[o].reply[y].content.indexOf(this.$refs.vmeChild.emojis[i]) > -1) {
                let len = data[o].reply[y].content.length;
                for (let j = 0; j < len; j++) {
                  this.plList[o].reply[y].content = this.plList[o].reply[y].content.replace(
                    this.$refs.vmeChild.emojis[i],
                    '<img src="../static/images/chat/emoji/' +
                      this.$refs.vmeChild._emojiName(
                        this.$refs.vmeChild.emojis[i]
                      ) +
                      '">'
                  );
                }
              }

              fhbq.forEach((item, i) => {
                // if (data[o].type == "publish") {
                if (data[o].reply[y].content.indexOf(item.flag) > -1) {
                  let len = data[o].reply[y].content.length
                  for (let j = 0; j < len; j++) {
                    this.plList[o].reply[y].content = this.plList[o].reply[y].content.replace(
                      item.flag,
                      '<img src="' +
                        item.imgSrc +
                        '" style="width:0.4rem;vertical-align: text-bottom;">'
                    );
                  }
                }
                // }
              });
            }
          }
        }

        fhbq.forEach((item, i) => {
          // if (data[o].type == "publish") {
          if (data[o].content.indexOf(item.flag) > -1) {
            let len = data[o].content.length;
            for (let j = 0; j < len; j++) {
              this.plList[o].content = this.plList[o].content.replace(
                item.flag,
                '<img src="' +
                  item.imgSrc +
                  '" style="width:0.4rem;vertical-align: text-bottom;">'
              );
            }
          }
          // }
        });
      }
    },
    flitText(t) {
      console.log(t);
      let len = this.$refs.vmeChild.emojis.length;
      let text = t;
      for (let i = 0; i < len; i++) {
        if (t.indexOf(this.$refs.vmeChild.emojis[i]) > -1) {
          let len2 = t.length;
          for (let j = 0; j < len2; j++) {
            console.log(111);
            text = t.replace(
              this.$refs.vmeChild.emojis[i],
              '<img src="../static/images/chat/emoji/' +
                this.$refs.vmeChild._emojiName(this.$refs.vmeChild.emojis[i]) +
                '">'
            );
          }
        }
      }

      return text;
    },

    goBack() {
      if (this.$route.query.mode) {
        this.$router.push({
          name: "guess",
          query: { mode: this.$route.query.mode }
        });
      } else {
        this.$router.go(-1);
      }
    },
    iptFocus() {
      this.dialogShow = true;
      if (navigator.userAgent.includes("MiuiBrowser")) {
        this.iptBottom = "0.72rem";
      }
	  // if (navigator.userAgent.includes("HuaweiBrowser")) {
	  //   this.iptBottom = "6.4rem";
	  // }
    }
  }
};
</script>
<style lang="less" >
.black-back {
  display: block;
  width: 12px;
  height: 20px;
  position: absolute;
  background: #ccc;
  top: 12px;
  left: 12px;
  background: url("../../assets/images/withdrawals/fanhui.png") no-repeat;
  background-size: 100% 100%;
}

#discuss {
  .main {
    .imgbox {
      display: flex;
      flex-wrap: wrap;

      .img-item {
        width: 2.933rem;
        height: 2.933rem;
        border-radius: 0.2rem;
        overflow: hidden;
        margin: 0 0.1rem;
        margin-bottom: 0.2rem;

        img {
          width: 100%;
          pointer-events: unset;
          min-height: 2.933rem;
        }
      }
    }

    .cut-box {
      height: 0.29rem;
      background: #f5f7fa;
      margin: 0.2rem 0;
    }

    .pl-box {
      padding: 0 0.3rem;

      .pl-num {
        font-size: 0.38rem;
        margin-bottom: 0.3rem;
      }

      .pl-content {
        display: flex;
        .pl-tx {
          width: 46px;
          height: 46px;
          border-radius: 50%;
        }
        .right-content {
          margin-left: 0.2rem;
          width: 100%;
        }

        .pl-name {
          font-size: 0.36rem;
          color: #999999;
          margin: 0.1rem 0 0.1rem 0;
        }

        .text1 {
          font-size: 0.38rem;
          width: 7.5rem;
          word-wrap: break-word;
          img {
            width: 0.44rem;
            vertical-align: text-bottom;
          }
        }

        .pl-time {
          display: flex;
          justify-content: space-between;
          margin: 0.36rem 0;

          .huifu {
            margin-right: -2.4rem;

            .huifu-icon {
              display: inline-block;
              width: 0.42rem;
              height: 0.42rem;
              background: url("../../assets/images/guess/pl-icon.png") no-repeat;
              background-size: 100% 100%;
              float: left;
              margin-right: 0.06rem;
            }
          }

          .like {
            .like-iocn {
              display: inline-block;
              width: 0.54rem;
              height: 0.39rem;
              background: url(../../assets/images/allIcon.png);
              background-position: 0 3.64rem;
              background-size: 1.13rem;
              float: left;
            }
          }

          .likesafter {
            .like-iocn {
              display: inline-block;
              width: 0.54rem;
              position: relative;
              height: 0.39rem;
              background: url(../../assets/images/allIcon.png);
              background-position: 0 3.24rem;
              background-size: 1.13rem;
            }
          }
        }

        .huifu-box {
          padding: 0.36rem;
          background: #f5f7fa;
          border-radius: 0.15rem;

          .firsthf {
            font-size: 0.36rem;
            padding-bottom: 0.2rem;
            .hf-text {
              cursor: pointer;
              img {
                width: 0.4rem;
                vertical-align: text-bottom;
              }
            }
            i {
              display: inline-block;
              padding: 0.04rem 0.1rem;
              font-size: 0.3rem;
              margin-right: 0.1rem;
            }

            .lz-icon {
              background: #e2ecf7;
              border-radius: 4px;
              color: #1a88ff;
            }

            .zb-icon {
              background: #ede5f9;
              border-radius: 4px;
              color: #d444f3;
            }

            .name {
              color: #5f84b0;
              margin-right: 0.08rem;
              i {
                font-size: 0.36rem;
                display: inline-block;
                margin: 0 -0.1rem;
              }
            }

            .secondhf {
              p {
                margin-top: 0.2rem;
                .name .zb {
                  color: #d444f3;
                  background: #ede5f9;
                  display: inline-block;
                  padding: 0.04rem 0.1rem;
                  font-size: 0.3rem;
                  border-radius: 5px;
                }
                .name .lz {
                  color: #1a88ff;
                  background: #e2ecf7;
                  display: inline-block;
                  padding: 0.04rem 0.1rem;
                  font-size: 0.3rem;
                  border-radius: 5px;
                }
              }
            }
          }
        }

        .huifu-box p:last-child {
          padding: 0;
        }

        .right-content {
          border-bottom: 1px solid #eeeeee;
          padding-bottom: 0.5rem;
          margin-bottom: 0.3rem;
        }
      }

      .pl-content:last-child .right-content {
        border: none;
        margin-bottom: 0;
      }
    }
  }

  .pl-input {
    position: fixed;
    width: 100%;
    padding: 0.2rem 0.3rem;
    bottom: 0;
    display: flex;
    align-items: center;
    color: #999999;
    justify-content: space-between;
    border-top: 1px solid #eeeeee;
    z-index: 1499;
    background: #fff;

    .input-bg {
      width: 76%;
      height: 0.93rem;
      background: #f5f7fa;
      border-radius: 0.5rem;

      input {
        width: 86%;
        height: 100%;
        padding-left: 0.4rem;
      }

      .emoj-icon {
        width: 0.58rem;
        height: 0.58rem;
        background: url("../../assets/images/chat/em.png") no-repeat;
        background-size: 100% 100%;
        position: absolute;
        top: 0.38rem;
        right: 3rem;
      }
    }

    .like-iocn {
      display: inline-block;
      width: 0.54rem;
      height: 0.39rem;
      background: url(../../assets/images/allIcon.png);
      background-position: 0 3.64rem;
      background-size: 1.13rem;
      float: left;
    }
    .sendbtn {
      height: 0.82rem;
      width: 20%;
      background: #ff513e;
      border-radius: 0.5rem;
      text-align: center;
      line-height: 0.82rem;
      font-size: 0.38rem;
      color: #fff;
      background-image: linear-gradient(to right, #ff3433, #ff7e66);
    }
  }
}
.successPop {
  position: fixed;
  z-index: 10001;
  width: 100%;
  height: 100%;
  .bgPop {
    background: rgba(0, 0, 0, 0.5);
    width: 100%;
    height: 100%;
  }
  .content {
    width: 45%;
    margin: 0 28%;
    z-index: 10002;
    background: #fff;
    text-align: center;
    position: absolute;
    top: 22%;
    padding: 0.6rem 0;
    border-radius: 5px;
    img {
      width: 1.3rem;
    }
    span {
      display: block;
    }
    .span1 {
      font-weight: 600;
      padding-top: 0.3rem;
      color: #000000;
      font-size: 0.4rem;
    }
    .span2 {
      padding-top: 0.1rem;
      color: #999999;
      font-size: 0.3rem;
    }
  }
}

.lz-icon {
  background: #e2ecf7;
  border-radius: 3px;
  color: #1a88ff;
  padding: 1px 4px;
  font-size: 0.3rem;
}

.zb-icon {
  background: #ede5f9;
  border-radius: 3px;
  color: #d444f3;
  padding: 1px 4px;
  font-size: 0.3rem;
}

.circle1 {
  position: absolute;
  left: 0;
  top: 0;
  border-radius: 50%;
  // border: 6px solid #ff2727;
  width: 50px;
  height: 50px;
  overflow: hidden;
  background: #ff2727;
  // opacity: 0.3;
  // right: 0.75rem;
  // text-align: center;
  // top: 3.18rem;
  // width: calc(100% - 6px);
  // height: calc(100% - 6px);
  // &:nth-child(1) {
  //   animation: circle-opacity 0.9s infinite;
  //   -webkit-animation: circle-opacity 0.9s infinite;
  //   -moz-animation: circle-opacity 0.9s infinite;
  //   -o-animation: circle-opacity 0.9s infinite;
  // }
  // &:nth-child(2) {
  //   animation: circle-opacity 0.9s infinite;
  //   -webkit-animation: circle-opacity 0.9s infinite;
  //   -moz-animation: circle-opacity 0.9s infinite;
  //   -o-animation: circle-opacity 0.9s infinite;
  //   animation-delay: 0.3s;
  //   -webkit-animation-delay: 0.3s;
  //   -o-animation-delay: 0.3s;
  //   -moz-animation-delay: 0.3s;
  // }
  // &:nth-child(3) {
  //   animation: circle-opacity 0.9s infinite;
  //   -webkit-animation: circle-opacity 0.8s infinite;
  //   -moz-animation: circle-opacity 0.8s infinite;
  //   -o-animation: circle-opacity 0.8s infinite;
  //   animation-delay: 0.6s;
  //   -webkit-animation-delay: 0.6s;
  //   -o-animation-delay: 0.6s;
  //   -moz-animation-delay: 0.6s;
  // }
  &:nth-child(1) {
    animation: circle-opacity 0.6s linear infinite;
    -webkit-animation: circle-opacity 0.6s linear infinite;
    -moz-animation: circle-opacity 0.6s linear infinite;
    -o-animation: circle-opacity 0.6s linear infinite;
    -ms-animation: circle-opacity 0.6s linear infinite;
  }
  &:nth-child(2) {
    animation: circle-opacity 0.6s linear infinite;
    -webkit-animation: circle-opacity 0.6s linear infinite;
    -moz-animation: circle-opacity 0.6s linear infinite;
    -o-animation: circle-opacity 0.6s linear infinite;
    -ms-animation: circle-opacity 0.6s linear infinite;
    animation-delay: 0.9s;
    -webkit-animation-delay: 0.9s;
    -o-animation-delay: 0.9s;
    -moz-animation-delay: 0.9s;
    -ms-animation-delay: 0.9s;
  }
  &:nth-child(3) {
    animation: circle-opacity 0.6s linear infinite;
    -webkit-animation: circle-opacity 0.6s linear infinite;
    -moz-animation: circle-opacity 0.6s linear infinite;
    -o-animation: circle-opacity 0.6s linear infinite;
    -ms-animation: circle-opacity 0.6s linear infinite;
    animation-delay: 0.6s;
    -webkit-animation-delay: 0.6s;
    -o-animation-delay: 0.6s;
    -moz-animation-delay: 0.6s;
    -ms-animation-delay: 0.6s;
  }
}
@keyframes circle-opacity {
  0% {
    border: 1.5px solid #ff2727;
    opacity: 0.6;
    -webkit-transform: scale(1.08);
    -o-transform: scale(1.08);
    -moz-transform: scale(1.08);
    transform: scale(1.08);
    // border-width:5px;
  }
  100% {
    border: 1.5px solid #ff2727;
    opacity: 0;
    -webkit-transform: scale(1.3);
    -o-transform: scale(1.3);
    -moz-transform: scale(1.3);
    transform: scale(1.3);
  }
}
@-o-keyframes circle-opacity {
  0% {
    border: 1.5px solid #ff2727;
    opacity: 0.6;
    -webkit-transform: scale(1.08);
    -o-transform: scale(1.08);
    -moz-transform: scale(1.08);
    transform: scale(1.08);
    // border-width:5px;
  }
  100% {
    border: 1.5px solid #ff2727;
    opacity: 0;
    -webkit-transform: scale(1.3);
    -o-transform: scale(1.3);
    -moz-transform: scale(1.3);
    transform: scale(1.3);
  }
}
@-moz-keyframes circle-opacity {
  0% {
    border: 1.5px solid #ff2727;
    opacity: 0.6;
    -webkit-transform: scale(1.08);
    -o-transform: scale(1.08);
    -moz-transform: scale(1.08);
    transform: scale(1.08);
    // border-width:5px;
  }
  100% {
    border: 1.5px solid #ff2727;
    opacity: 0;
    -webkit-transform: scale(1.3);
    -o-transform: scale(1.3);
    -moz-transform: scale(1.3);
    transform: scale(1.3);
  }
}
@-webkit-keyframes circle-opacity {
  0% {
    border: 1.5px solid #ff2727;
    opacity: 0.6;
    -webkit-transform: scale(1.08);
    -o-transform: scale(1.08);
    -moz-transform: scale(1.08);
    transform: scale(1.08);
    // border-width:5px;
  }
  100% {
    border: 1.5px solid #ff2727;
    opacity: 0;
    -webkit-transform: scale(1.3);
    -o-transform: scale(1.3);
    -moz-transform: scale(1.3);
    transform: scale(1.3);
  }
}
</style>
