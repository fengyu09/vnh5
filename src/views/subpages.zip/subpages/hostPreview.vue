<template>
  <div class="hostPreview-container">
    <div class="head">
      <div @click="$router.go(-1)" style="z-index: 10000001;">
        <img style="width: 0.31rem;margin-top: .3rem" src="../../assets/images/gray-back-icon.png" alt="">
      </div>
      <span>直播预告</span>
    </div>
    <myScrollX v-if="allLottery.length">
      <div class="clearfix preview-list" ref="personTab">
        <div
            v-for="(v,index) in allLottery"
            :key="index"
            class="lottery-item"
            @click="changeLottery(v.room_id,v.name,v.video_url,v.anchor_id)"
            :class="v.room_id==currId?'active':''"
        >
          <span>{{v.name}}</span>
        </div>
        
      </div>
    </myScrollX>
    <div class="preview-container">
      <myScroll  ref="scrollWrapper"  :data="playList" :bottom="0" :top="2.6" :bgColor="'f5f7fa'">
        <div class="preview-content"><preview :type="currId"/></div>
      </myScroll>
    </div>
  </div>
</template>

<script>
import myScrollX from "../../components/myScrollX.vue"; //横向滚动
import myScroll from "../../components/myScroll.vue"; //纵向滚动
import preview from '../../components/preview.vue'
export default {
  name: "hostPreview",
  data() {
    return {
      allLottery:[],
      playList:{},
      currId:0,
      currName:''
    };
  },
  created() {
    this.getGame();
  },
  components:{
    myScrollX,
    preview,
    myScroll
  },
  methods: {
    goback() {
      // this.$router.push('/member');
    },
    ScrollX() {

      let width = this.allLottery.length * 2.45;
      this.$refs.personTab.style.width = width + "rem";
    },
    changeLottery(id, name) {
      this.currId = id;
      this.currName = name;
      this.$nextTick(() => {
        setTimeout(() => {
          this.$refs.scrollWrapper.Myscroll.scrollTo(0, 0);
        }, 20);
      });
      //获取预告
    },
    //获取彩种列表
    async getGame(flag) {
      let res = await this.$http.post(this.versionLive2+"live/get_room_list/");
      if (res.data && res.data.code == 1) {
        this.allLottery = res.data.data || [];
        this.allLottery.unshift({
          name:'全部',
          room_id:0
        })
//        this.currId = this.allLottery[0].lottery_id;
//        this.currRoomId = this.allLottery[0].anchor_id;
//        this.currName = this.allLottery[0].cname;
//        this.currUrl = this.allLottery[0].video_url;
        this.playList.allLottery = this.allLottery;
      }
    },
  },
  watch:{
    allLottery: function() {
      this.$nextTick(() => {
        this.ScrollX();
      });
    },
  },
  mounted() {
    //        到时候放App全局
    document.body.addEventListener(
      "touchmove",
      function(e) {
        e.preventDefault(); // 阻止默认的处理方式(阻止下拉滑动的效果)
      },
      { passive: false }
    );
  }
};
</script>

<style scoped lang="less">
  .preview-container .wrapperY{
    background: #f5f7fa !important;
  }
  // .preview-content{
  //   padding-top: 0.25rem;
  // }
.hostPreview-container{
  .head {
    width: 100%;
    height: 1.2rem;
    line-height: 1.2rem;
    text-align: center;
    position: relative;
    font-size: 0.42rem;
    font-weight: bold;
    >div{
      position: absolute;
      top: 0rem;
      left: .35rem;
      width: 1rem;
      height: 100%;
      text-align: left;
    }
  }
  .preview-list{
    padding: .2rem 0 .4rem 2%;
    background: #fff;
    >div{
      display: inline-block;
      background: #f5f7fa;
      margin-right: .2rem;
      border-radius: 16px;
      padding:.2rem .35rem;
      &.active{
        color: #fff;
        background:linear-gradient(90deg,rgba(255,49,49,1),rgba(255,128,103,1));
      }
    }
  }
}
</style>
