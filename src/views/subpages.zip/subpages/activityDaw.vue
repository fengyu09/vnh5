<template>
    <div>
        <flexbox class="infoHead">
            <flexbox-item :span="1/10">
                <div
                @click="$router.go(-1)"
                class="flex-demo"
                style="padding-top: 0.7em; z-index: 10000001;"
                >
                <img src="../../assets/images/activityDraw/fanhui.png" alt />
                </div>
            </flexbox-item>
            <flexbox-item>
                <div class="flex-demo tickling">活动抽奖</div>
            </flexbox-item>
            <flexbox-item :span="2/10">
                <div class="flex-demo" @click="myWinning()">我的中奖</div>
            </flexbox-item>
        </flexbox>
        
       <myScroll :bottom='0'>
            <div class="container clearfix" :class="lotteryType==1?'yecj':'zscj'">
            <div class="lucky-wheel" v-show="lotteryType==1">
                <!-- 中奖滚动消息 -->
                <div class="zj-prizeList">
                    <i></i>
                    <marquee scrollAmount="3" scrolldelay="50" direction="left">
                        <span
                                v-for="(v,index) in recordList"
                                :key="index"
                                v-show="recordList.length"
                        >{{v.phone}}&nbsp;&nbsp;&nbsp; <span style="color:#FFD386;">抽中&nbsp;&nbsp;&nbsp;{{v.name}}*{{v.number}}</span> </span>
                        <span v-show="!recordList.length">暂无中奖记录</span>
                    </marquee>
                </div>
                <!-- 抽奖规则 -->
                <div class="rule" @click="rulePopup = true">抽奖规则</div>
                <div class="wheel-main">
                    <div class="wheel-pointer" @click="beginRotate()"></div>
                    <div class="wheel-bg" :style="rotateStyle">
                    <div class="prize-list">
                        <div
                        class="prize-item"
                        v-for="(item,index) in prizeList"
                        :key="index"
                        :style="item.style"
                        >
                        <div class="prize-pic">
                            <img :src="item.icon" :class="{'wzs':item.name=='钻石','car':item.name=='帝王花车','fhjc':item.name=='凤凰机车','lbjn':item.name=='兰博基尼'}"/>
                        </div>
                        <div class="prize-type" :style="item.name=='谢谢参与'?'padding-top:.4rem':''">{{item.name}}</div>
                        <div class="prize-num"><i v-if="item.name!='钻石'&&item.name!='谢谢参与'"></i>{{item.number>0?item.number:''}}</div>
                        </div>
                    </div>
                    </div>
                </div>
                <!-- 剩余次数 -->
                <div class="left-time">抽奖 <i>2</i> 元/次</div>
                <!-- 购买 -->
                <div class="balance ye">
                    <div class="num fl">
                        <img src="../../assets/images/activityDraw/ye.png" alt="">
                        <span>余额: <strong>{{useMoney}}</strong></span>
                    </div>
                    <div class="go-buy-btn fr" @click="recharge()">充值</div>
                </div>
                
            </div>
            <div class="lucky-wheel" v-show="lotteryType==0">
                <!-- 中奖滚动消息 -->
                <div class="zj-prizeList">
                    <i></i>
                    <marquee scrollAmount="3" scrolldelay="50" direction="left">
                        <span v-for="(v,index) in recordList" :key="index" v-show="recordList.length">{{v.phone}}&nbsp;&nbsp;&nbsp; 
                            <span style="color:#FFD386;">抽中&nbsp;&nbsp;&nbsp;{{v.name}}*{{v.number}}</span> 
                        </span>
                        <span v-show="!recordList.length">暂无中奖记录</span>
                    </marquee>
                </div>
                <div class="wheel-main">
                    <div class="wheel-pointer" @click="beginRotate()"></div>
                    <div class="wheel-bg" :style="rotateStyle">
                    <div class="prize-list">
                        <div
                        class="prize-item"
                        v-for="(item,index) in prizeList"
                        :key="index"
                        :style="item.style"
                        >
                        <div class="prize-pic">
                            <img :src="item.icon" :class="{'wzs':item.name=='钻石','car':item.name=='帝王花车','fhjc':item.name=='凤凰机车','lbjn':item.name=='兰博基尼'}"/>
                        </div>
                        <div class="prize-type" :style="item.name=='谢谢参与'?'padding-top:.4rem':''">{{item.name}}</div>
                        <div class="prize-num"><i v-if="item.name!='钻石'&&item.name!='谢谢参与'">*</i>{{item.number>0?item.number:''}}</div>
                        </div>
                    </div>
                    </div>
                </div>
                <!-- 剩余次数 -->
                <div class="left-time">剩余<i>{{count}}</i>次 抽奖</div>
                <!-- 购买 -->
                <div class="balance " :class="lotteryType==1?'ye':'zs'">
                    <div class="num fl">
                        <img src="../../assets/images/activityDraw/zs.png" alt="">
                        <span>钻石: <strong>{{zsMount}}</strong></span>
                    </div>
                    <div class="go-buy-btn fr" @click="isBuy=true">购买抽奖次数</div>
                </div>
                
            </div>
            <div class="big-tab " v-if="$store.state.isPure==0">
                <span :class="lotteryType==1?'tab-ye':''" @click="lotteryTab(1)">余额抽奖</span>
                <span :class="lotteryType==0?'tab-zs':''" @click="lotteryTab(0)">钻石抽奖</span>
            </div>
        </div>
       </myScroll>
        <!-- 购买次数 -->
        <div class="buy-time" v-if="isBuy">
            <div class="bug-time-content">
                <div class="remove-btn" @click="isBuy=false"></div>
                <p class="buy-tip">购买抽奖次数</p>
                <div class="input-box">
                    <div class="cut-btn" @click="changeTime(0)"></div>
                     <input type="tel" v-model="buyTime" maxlength="9">
                    <div class="add-btn" @click="changeTime(1)"></div>
                </div>
                <div class="total-zs">总计：<i></i>{{buyTime*20}}</div>
                <div class="bug-btn" @click="toBuy">Xác nhận购买</div>
            </div>
        </div>
         <!-- 钻石余额不足 -->
        <div class="exchange-pup" v-if="exchangePup">
            <div class="pup-content">
                <div class="pup-close"  @click="exchangePup=false"><img src="../../assets/images/activityDraw/x-2.png" alt=""></div>
                <div v-if="lotteryType==1">
                    <img style="width:58%;" src="../../assets/images/activityDraw/cz-pic.png" alt="">
                    <p>您的余额不足请充值</p>
                    <div class="btn" @click="recharge()">去充值</div>
                </div>
                <div v-if="lotteryType==0">
                    <img style="width:36%;margin-top:20px" src="../../assets/images/activityDraw/dh-pic.png" alt="">
                    <p>钻石余额不足，快去兑换吧</p>
                    <div class="btn" @click="recharge()">去兑换</div>
                </div>
            </div>
        </div>
        <!-- 抽奖规则弹窗 -->
        <div class="rule-pup" v-if="rulePopup">
            <div class="rule-content">
                <div class="rule-close" @click="rulePopup = false"><img src="../../assets/images/activityDraw/clone.png" alt=""></div>
                <div class="content-box">
                    <myScroll :bottom="0.3" :top="0.5" >  
                        <h4 class="title">抽奖规则</h4>
                        <p>天天赢好礼，幸运大转盘，为回馈广大新老用户，特此推出幸运大转盘活动。</p>
                        <div>
                            <h6>一、活动规则</h6>
                            <p>1、凡是我平台会员，均可参加。</p>
                            <p>2、转盘抽奖分为“余额抽奖”和“钻石抽奖”。 </p>
                            <p>3、“余额抽奖”每次消耗 2 元，自动扣除，余额不足时无法抽奖，升级 VIP 可获得免费余额抽奖 次数。</p>
                            <p>4、“钻石抽奖”每次消耗 20 钻石，抽奖次数不足时及时购买抽奖次数，钻石不足时，及时兑换钻石，升级贵族可获得免费钻石抽奖次。</p>
                            <p>5、点击大转盘中心的“抽奖”按钮即可抽奖，待转盘停止时，转盘指针指向的奖品则为本次抽奖所得。</p>
                        </div>
                        <div>
                            <h6>二、奖品设置</h6>
                            <table>
                                <tr >
                                    <td class="w130" rowspan="2">余额抽奖</td>
                                    <td>0.18 元 </td>
                                    <td>0.38 元</td>
                                    <td>0.88 元</td>
                                    <td>再来一次</td>
                                </tr>
                                <tr>
                                    <td>5.88 元 </td>
                                    <td>18.88 元</td>
                                    <td>38.88 元</td>
                                    <td>谢谢参与</td>
                                </tr>
                            </table>
                            <table>
                                <tr >
                                    <td class="w130" rowspan="2">钻石抽奖</td>
                                    <td>5钻石</td>
                                    <td> 10钻石</td>
                                    <td> 炸弹*5</td>
                                    <td> 288 钻石</td>
                                </tr>
                                <tr>
                                    <td>凤凰机车*1</td>
                                    <td>兰博基尼*1</td>
                                    <td>帝王花车*1</td>
                                    <td>谢谢参与</td>
                                </tr>
                            </table>
                        </div>  
                    </myScroll>                      
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import {mapState} from "vuex";
import myScroll from "../../components/myScroll.vue"; //纵向滚动
const CIRCLE_ANGLE = 360
const config = {
  // 总旋转时间
  duration: 3000,
  // 旋转圈数
  circle: 8,
  mode: 'ease-in-out'
}
import {
  Flexbox,
  FlexboxItem
 
} from "vux";
export default {
    name: "activityDaw",
    data(){
        return{
            rulePopup:false, //规则弹窗
            exchangePup:false, //余额、钻石不足
            lotteryType:1, //1余额抽奖 0钻石抽奖
            isBuy:false,
            buyTime:1,//购买次数
            useMoney:null, //用户余额
            count: null, // 剩余抽奖次数
            duration: 3000, // 转盘旋转时间
            prizeList: [], // 奖品列表
            rotateAngle: 0, // 旋转角度
            index: 0,
            prize: null,
            prizeObj:{},
            recordList:[],//中奖记录
            isKc:true,
            isLogin:true,
            zsMount:0,
        }
    },
    created(){
        // 初始化一些值
        this.angleList = []
        // 是否正在旋转
        this.isRotating = false
        // 基本配置
        this.config = config
        // 获取奖品列表
        this.getGiftList();
        //获取中奖记录
        this.getRecordList();
        this.zsQuest();
    },
    computed: {
        rotateStyle () {
        return `
            -webkit-transition: transform ${this.config.duration}ms ${this.config.mode};
            transition: transform ${this.config.duration}ms ${this.config.mode};
            -webkit-transform: rotate(${this.rotateAngle}deg);
                transform: rotate(${this.rotateAngle}deg);`
        },
        ...mapState(["zjArr"])
        
    },
    components: {
        Flexbox,
        FlexboxItem,
        myScroll
    },
    methods:{
        zsQuest() {
            // 获取钻石/api/v1/user/diamond_now/
            if (!this.$store.state.codeToken||this.$store.state.userinfo.user_id<0) return;
            // this.zsMount = "Đang nhận...";
            this.$http
                .get(this.versionLive2+"user/diamond_now/?user_id=" + this.$store.state.userinfo.user_id)
                .then(res => {
                if (res && res.data.code == 1) {
                    if (res.data.data.diamond == null) {
                    this.zsMount = 0;
                    // this.SETDIAMOND(0)
                    } else {
                    // this.zsMount = parseFloat(res.data.data.diamond).toFixed(2);
                    this.zsMount = parseFloat(res.data.data.diamond);
                    // this.SETDIAMOND(res.data.data.diamond);
                    }
                }
                }).catch(res=>{
                this.zsMount = "0.00";
            });
        },
        lotteryTab(type){
            this.lotteryType = type;
            this.getGiftList();
            this.getRecordList();
        },
        myWinning(data) {
            this.$router.push('/myWinning');
        },
        //获取中奖记录
        async getRecordList(){
            let res = await this.$http.get(this.versionLive2+'user/turntable_log/',{params:{
            limit:20,
            get_type:this.lotteryType
        }});
            if(res && res.data.code==1){
                this.recordList = res.data.data || [];

                // console.log( this.recordList.length)
                //console.log(7777,this.recordList)
            }
        },
        toastTitle () {
            let tip='';
            let msg = '';
            if(this.prize.status==1){
                tip="中奖啦！";
                msg = "<p style='line-height:.8rem;padding:.3rem 0;color: #445779;font-size:.4rem'>恭喜您获得"+this.prize.name+"*"+this.prize.number+"，稍后发放奖品,请耐心等待.</p>";
            }else if(this.prize.status==-1){
                tip="很遗憾！";
                msg = "<p style='line-height:.8rem;padding:.3rem 0;color: #445779;font-size:.4rem'>此次没有中奖，再接再厉.</p>";
            }
            this.$vux.confirm.show({
                    title:tip,
                    content:msg,
                    showCancelButton:false,
                    confirmText:"知道了",
                    onConfirm : () => {
                    }
                });
        },
        //获取礼物列表
        async getGiftList(){
           
            let res = await this.$http.get(this.versionLive2+'user/turntable_list/',{params:{
            get_type:this.lotteryType
        }});
            if(res && res.data.code==1){
                // this.prizeList = res.data.data;
                this.prizeList = this.formatPrizeList(res.data.data)
                this.count = res.data.draws_num;
                this.useMoney = res.data.user_money
            }
        },
        changeTime(f){
                if(f){
                if(this.buyTime>=999999999){
                    this.buyTime = 999999999;
                    // this.$vux.toast.text('');
                }
                else this.buyTime++; 
                }else{
                    if(this.buyTime<1) this.buyTime=0
                    else this.buyTime--
                }

        },
        async toBuy(){
            this.$vux.confirm.hide();
            if(this.buyTime<1) return this.$vux.toast.text('至少购买一次','bottom');
            this.$vux.loading.show({ text: "购买中..." });
            let res = await this.$http.post(this.versionLive2+'user/get_turntable_chance/',{
                times:this.buyTime
            })
            this.$vux.loading.hide();
            if(res && res.data.code==1){
                this.buyTime = 1;
                this.count = res.data.data.times_now;
                this.zsQuest();
            }
            // else if(res.data.code==0){
            //     //余额不足
            //     this.exchangePup= true;
            // }
            this.$vux.toast.text(res.data.msg); 
            this.isBuy = false;
            
        },
        // 格式化奖品列表，计算每个奖品的位置
        formatPrizeList (list) {
        // 记录每个奖的位置
        const angleList = []

        const l = list.length
        // 计算单个奖项所占的角度
        const average = CIRCLE_ANGLE / l

        const half = average / 2

        // 循环计算给每个奖项添加style属性
        list.forEach((item, i) => {

            // 每个奖项旋转的位置为 当前 i * 平均值 + 平均值 / 2
            const angle = -((i * average) + half)
            // 增加 style
            item.style = `-webkit-transform: rotate(${angle}deg);
                        transform: rotate(${angle}deg);`

            // 记录每个奖项的角度范围
            angleList.push((i * average) + half )
        })

        this.angleList = angleList

        return list
        },
      loadMoney() {
      if (!this.$store.state.codeToken) return;
      this.$http.get("/api2/index/balance").then(res => {
        if (res && res.data.code == 1) {
          this.useMoney = res.data.data.balance || "0"; //用于计算的
        }
      });
    },
        async beginRotate() {
            if(!this.$store.state.codeToken){
                this.$popup();
                return;
            }

        // 添加次数校验 钻石
        if(this.count === 0 && this.lotteryType==0){
                this.$vux.confirm.show({
                    title:'',
                    content:'<p>今日的抽奖次数已用完，您可以提高会员等级</p><p>增加每日抽奖次数也可以单独</p><p>购买抽奖次数.</p>',
                    showCancelButton:false,
                    confirmText:"知道了",
                    onConfirm : () => {
                    }
                });
                // this.exchangePup = true;
            return
        } 
        //添加校验  余额不足
        if(this.useMoney <2 && this.lotteryType==1) return this.exchangePup = true;
        // 开始抽奖
        // 这里这里向服务端发起请求，得到要获得的奖
        // 可以返回下标，也可以返回奖品 id，通过查询 奖品列表，最终得到下标
        if(!this.isKc) return
        this.isKc = false;
        let res = await this.$http.post(this.versionLive2+'user/get_gift/',{get_type:this.lotteryType});
            if(res && res.data.code==1){
                    this.index = res.data.data.id;
                    // 减少剩余抽奖次数
                    if(this.lotteryType==0){
                        this.zsQuest();
                        this.count = res.data.data.time_now;
                    } else{
                        this.useMoney = res.data.data.after_money
                        // this.loadMoney();
                    }
                    //中奖信息
                    this.prizeObj = res.data.data;
                    this.rotating();
            }else{
                this.$vux.confirm.show({
                    title:'',
                    content:res.data.msg,
                    showCancelButton:false,
                    onConfirm : () => {
                    }
                });
            }

        // 随机获取下标
        // this.index = this.random(this.prizeList.length - 1);

        // 减少剩余抽奖次数
        // this.count--
    
        // 开始旋转
        this.rotating()
        },
        // random (max, min = 0) {
        // return parseInt(Math.random() * (max - min + 1) + min)
        // },
        rotating() {
        const { isRotating, angleList, config, rotateAngle, index } = this

        if (isRotating) return

        this.isRotating = true
        
        // 计算角度
        let angle = 0;
       if(this.lotteryType==1){
            angle =
            // 初始角度
            rotateAngle +
            // 多旋转的圈数
            config.circle * CIRCLE_ANGLE +
            // 奖项的角度
            angleList[index-8-1] -
            (rotateAngle % CIRCLE_ANGLE)
            console.log(angle)
       }else{
             angle =
            // 初始角度
            rotateAngle +
            // 多旋转的圈数
            config.circle * CIRCLE_ANGLE +
            // 奖项的角度
            angleList[index-0-1] -
            (rotateAngle % CIRCLE_ANGLE)
       }

            
            this.rotateAngle = angle

            // 旋转结束后，允许再次触发
            setTimeout(() => {
            
            this.rotateOver()
            }, config.duration + 1000)
        },
        rotateOver () {
            this.isRotating = false
            this.isKc = true;
            this.prize = this.prizeObj;

            // console.log(this.prize, this.index)
            this.toastTitle();
        },
        //关闭弹窗
        closeToast() {
            // this.prize = null;
            this.$vux.confirm.hide();
            this.$emit("closeFunc",false)
        },
        recharge(){
            this.$router.push('/recharge')
        },
    
    }
}
</script>
<style lang="less" scoped>
.rem(@name,@px){
    @{name}:unit(@px/75,rem)
}
.infoHead {
  height: 1.2rem;
  line-height: 1.2rem;
}
.flex-demo {
  text-align: center;
  img {
    width: 0.25rem;
  }
}   
.tickling {
  font-weight: 550;
  font-size: 0.45rem;
}
.big-tab{
    .rem(width,508);
    .rem(height,68);
    .rem(line-height,68);
    .rem(font-size,28);
    color: #445779;
    margin: 0 auto;
    background:#fff;
    overflow: hidden;
    .rem(border-radius,50);
    span{
        width: 50%;
        .rem(line-height,69);
        text-align: center;
        float: left;
        .rem(border-radius,50);
        &.tab-ye{
            background: linear-gradient(90deg,#4e01f0, #675afc);
            color: #fff;
        }
        &.tab-zs{
            background: linear-gradient(90deg,#ff3632, #ff8064);
            color: #fff;
        }
    }
}
 // 购买弹框
.buy-time{
    position: fixed;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    background: rgba(0,0,0,.5);
    z-index: 2223;
    .bug-time-content{
        position: absolute;
        background: #fff;
        border-radius: .3rem;
        padding: .8rem;
        left: 50%;
        top: 50%;
        transform: translate(-50%,-50%);
        text-align: center;
        .remove-btn{
            .rem(width,22);
            .rem(height,22);
            background: url(../../assets/images/hmlz-icon2.png);
            background-size: contain;
            position: absolute;
            right: .4rem;
            top:.4rem;
        }
        .buy-tip{
            text-align: center;
            .rem(font-size,32);
            font-weight: bold;
            margin-bottom: .5rem;
        }
        .input-box{
            text-align: center;
            .rem(height,69);
            input{
                display: inline-block;
                .rem(width,300);
                .rem(height,68);
                .rem(line-height,68);
                border-radius: .1rem;
                border:1px solid #ddd;
                margin: 0 .2rem;
                text-align: center;
                vertical-align: top;

            }
            .add-btn{
                .rem(width,69);
                .rem(height,69);
                    display: inline-block;
                background: url(../../assets/images/seli_button_6_6.png);
                    background-size: contain;
            }
            .cut-btn{
                .rem(width,69);
                .rem(height,69);
                    display: inline-block;
                    background: url(../../assets/images/dis_button_6_6.png);
                    background-size: contain;
            }
        }
        .total-zs{
            margin:.4rem 0;
            .rem(font-size,30);
            i{
                display: inline-block;
                .rem(width,34);
                .rem(height,31);
                    background: url(../../assets/images/chat/zuanshi-min.png) no-repeat;
                    background-size: contain;
                    margin-right: .2rem;
                    vertical-align: middle;
            }
        }
        .bug-btn{
            background: linear-gradient(90deg, #FF3634, #FF7F66);
            color: #fff;
            text-align: center;
            .rem(width,490);
            .rem(height,80);
            .rem(line-height,80);
            border-radius: 20px;
            .rem(font-size,32);
        }
        
    }
}
// 充值兑换小弹窗
.exchange-pup{
    position: fixed;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    background: rgba(0,0,0,.5);
    z-index: 1000;
    .pup-close{
        .rem(width,30);
        position: absolute;
        .rem(top,30);
        .rem(right,30);
        cursor: pointer;
    }
    .pup-content{
        .rem(width,649);
        .rem(height,489);
        background: url("../../assets/images/activityDraw/pup-bg.png") no-repeat;
        background-size: contain;
        position: absolute;
        left: 50%;
        top: 50%;
        transform: translate(-50%,-50%);
        text-align: center;
        padding: 17px 25px;
        p{
            line-height: 30px;
            .rem(font-size,30);
            
            padding: 15px 0;
        }
        .btn{
            .rem(width,380);
            .rem(height,68);
            .rem(font-size,36);
            color: #fff;
            background: linear-gradient( 90deg,#ff3534,#ff7c64);
            border-radius: 30px;
            padding: 5px 10px;
            margin: 0 auto;
            cursor: pointer;
        }
    }
   
}

//抽奖规则&弹窗
.wrapperY{
    min-width: 200px;
    .rem(width,710) !important;
    .rem(height,800);
}
.rule{
    .rem(width,140);
    .rem(height,50);
    .rem(line-height,50);
    .rem(font-size,24);
    color: #fff;
    text-align: center;
    background: linear-gradient(90deg, #FFB82C 0%, #FFE565 100%);
    border-radius: 0px 12.5px 12.5px 0px;
}
.rule-pup{
    position: fixed;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    background: rgba(0,0,0,.5);
    z-index: 1000;
    .rule-content{
        .rem(width,710);
        .rem(height,800);
        background: #fff;
        border-radius: 10px;
        margin: 0 auto;
        .rem(margin-top,250);
        .rem(padding,20);
        position: relative;
        .rule-close{
            .rem(width,52);
            position: absolute;
            .rem(bottom,-100px);
            left: 50%;
            transform: translate(-50%,0);
        }
    }
    .content-box{
        height: 100%;
        color: #445779;
        .rem(font-size,24);
        // overflow-y: scroll;
        .title{
            .rem(font-size,36);
            text-align: center;
            .rem(margin-bottom,20);
        }
        h6{
            .rem(font-size,28);
            color: #1486FF;
            font-weight: normal;
            .rem(margin-top,10);
            .rem(margin-bottom,10);
        }
        table{
            width: 100%;
            border-collapse:collapse;
            text-align: center;
            border: 1px solid #6A86B9;
            .rem(margin-bottom,10);
            &:last-of-type{
                margin-bottom: 30px;
            }
            tr{
                border-collapse:collapse;
                border: 1px solid #6A86B9;

            }
            td{
                .rem(height,48);
                border-collapse:collapse;
                border: 1px solid #6A86B9;

            }
            .w130{
                .rem(width,130);
            }
        }
    }
}
 .container {
     .rem(min-height,1300);
        &.yecj{
            background: #3e1da0 url("../../assets/images/activityDraw/bj.png") no-repeat top;
            background-size: contain;
            .zj-prizeList{
                background: url(../../assets/images/activityDraw/noticebar.png) no-repeat;
                background-size: 100% 100%;
            }
            .balance{
                &.ye{
                    background: url(../../assets/images/activityDraw/balance-ye.png) no-repeat;
                    background-size: 100% 100%;
                }
            }
            .wheel-bg{
                color: #752ce9 !important;
                background: url("../../assets/images/activityDraw/dzp_bg.png") no-repeat center top;
                background-size: 100%;
                .prize-item:nth-of-type(even){
                    color: #fff !important;
                }
            }
            .wheel-pointer {
                background: url("../../assets/images/activityDraw/zd.png") no-repeat center top;
                background-size: 100%;
            }
        }    
        &.zscj{
            background: #f4433f url("../../assets/images/activityDraw/zs-bj.png") no-repeat top;
            background-size: contain;
            .zj-prizeList{
                background: url(../../assets/images/activityDraw/zs-ti.png) no-repeat;
                background-size: 100% 100%;
            }
            .balance{
                &.zs{
                    background: url(../../assets/images/activityDraw/balance-zs.png) no-repeat;
                    background-size: 100% 100%;
                }
            }  
            .wheel-bg{
                color: #e0504e;
                background: url("../../assets/images/activityDraw/zs-bp.png") no-repeat center top;
                background-size: 100%;
                .prize-item:nth-of-type(even){
                    color: #fff !important;
                }
            }
            .wheel-pointer {
                background: url("../../assets/images/activityDraw/zs-zz.png") no-repeat center top;
                background-size: 100%;
            }
        }         
    }
        .lucky-wheel {
            width: 100%;
            .rem(padding-top,40);
            .zj-prizeList{
                marquee{
                    width: 93%;
                    span{
                        padding-right: .5rem;
                    }
                }
                .rem(height,50);
                .rem(line-height,50);
                .rem(width,700);
                color: #fff;
                .rem(font-size,18);
                font-weight: bold;
                margin: 0 auto .1rem;
                .rem(margin-bottom,120);
                padding:0 .3rem 0 .9rem;
                position: relative;
                i{
                    display: inline-block;
                    .rem(width,34);
                    .rem(height,29);
                    background: url(../../assets/images/activityDraw/tx.png) no-repeat;
                    background-size: contain;
                    position: absolute;
                    left: .4rem;
                    top:.2rem;
                }
            }
            .balance{
                .rem(width,561);
                .rem(height,68);
                text-align: center;
                margin: 0 auto;
                .rem(margin-bottom,65);
                
                .num{
                    .rem(line-height,68);
                    color: #fff;
                    .rem(font-size,24);
                    strong{
                        .rem(font-size,30);
                    }
                    img{
                        .rem(width,38);
                        .rem(margin-top,15);
                        .rem(margin-right,15);
                        float: left;
                    }
                }
                .go-buy-btn{
                    .rem(height,68);
                    .rem(line-height,68);
                    .rem(width,240);
                    background: url(../../assets/images/activityDraw/btn.png) no-repeat;
                    background-size: contain;
                    color: #fff;
                    .rem(font-size,28);
                    font-weight: bold;
                    text-align: center;
                    margin: 0 auto;
                }
            }
           
            .left-time{
                width: 100%;
                text-align: center;
                .rem(height,81);
                .rem(line-height,81);
                color: #FAFFFE;
                .rem(font-size,30);
                font-weight: 500;
                text-align: center;
                margin: 0 auto;
                .rem(margin-bottom,25);
                i{
                    .rem(font-size,36);
                    padding: 0 .1rem;
                    font-family: number2;     
                }
                
            }
        }
        .wheel-main {
            margin: 0 auto;
            position: relative;
            
            .rem(width,680);
            .rem(height,680);
            }
        .wheel-bg {
        position: absolute;
        top: 0;
        left: 0;
        z-index: 1;
        width: 100%;
        height: 100%;
        }
        .wheel-pointer {
            position: absolute;
            top: 50%;
            left: 50%;
            z-index: 2;
            .rem(width,263);
            .rem(height,263);
           
            transform: translate3d(-50%, -50%, 0);
        }
        .wheel-bg div {
            text-align: center;
        }
        .prize-list {
            width: 100%;
            height: 100%;
            position: relative;
        }
        .prize-list .prize-item {
            position: absolute;
            .rem(width,190);
            .rem(height,285);
            top: 10%;
            left: 50%;
            .rem(margin-left,-95);
            transform-origin: 50% 100%;
        }

        .prize-pic img {
            width: .6rem;
            margin-top: .8rem;
            &.wzs{
                width:.3rem;
                    margin-top: .9rem;
            }
            &.car{
                // width:.9rem;
                // margin-top: 0.8rem;
            }
            &.fhjc{
                // width:1.2rem;
                // margin-top: 0.3rem;
            }
            &.lbjn{
                // width:1.2rem;
                // margin-top: 0.4rem;
            }
            }
            .prize-count {
            font-size: 0.875rem;
            }
            .prize-type {
            .rem(font-size,18);
            }
            .main {
            position: relative;
            width: 100%;
            min-height: 14.25rem;
            background: rgb(243, 109, 86);
            padding-bottom: 1.6875rem;
            }
            .main-bg {
            width: 100%;
            height: 6.5625rem;
            position: absolute;
            top: -3.4375rem;
            left: 0;
            // background: url("../assets/img/luck_bg.png") no-repeat center top;
            // background-size: 100%;
        }
</style>