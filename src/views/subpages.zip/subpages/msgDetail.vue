<template>
    <div class="msgDetail">
       <div class="header">
            <div @click="$router.go(-1);">
                <i class="go-back"></i>
            </div>
            <div>
                <h3>Chi tiết</h3>
            </div>
        </div>
        <div class="msgDetail-content">
           <h3>{{detailData.title}}</h3>
           <div v-html="detailData.content">

           </div>
        </div>
    </div>
</template>
<script>
export default {
    name:'msgDetail',
    data(){
        return{
            detailData:''
        }
    },
    created(){
        this.$vux.loading.show();
        this.$http
          .get("/api/live/sport/get_message/", {
            params: {
             msg_id:this.$route.query.msg_id
            }
          }).then(res=>{
              this.$vux.loading.hide();
              if(res&&res.data.code==1){
                  this.detailData=res.data.data
              }
          })
    }
}
</script>
<style lang="less" scoped>
.msgDetail{
    .header{
         display: flex;
        background: #fff;
        align-items: center;
        justify-content: space-between;
        padding: 0 0.346rem;
        .go-back{display: block;width: 1.25rem;height:1.2rem;background: url('../../assets/images/gray-back-icon.png') left center no-repeat;background-size: 20%;}
        h3{font-weight: 550;font-size: 0.45rem;
        position: absolute;
        top: 0;
        left: 50%;
        transform: translateX(-50%);
        }
    }
    .msgDetail-content{
        border-top: 1px solid #EEEEEE;
        margin-top: 1.2rem;
        padding: 0 0.4rem;
        color: #000;
        font-size: 0.32rem;
        line-height: 0.5rem;
        h3{font-size: 0.36rem;font-weight: bold;text-align: center;padding: 0.3rem 0;}
      
    }
}
    
</style>