<template>
    <div class="km-rechargeList">
        <headerOne/>
        <myScroll :bgColor="'f5f7fa'" :bottom="0" :top="1.2" ref="scrollWrapper">
          <div class="kml-content">
              <ul>
                  <li v-for="(v,index) in ksList" :key="index" class="clearfix">
                      <div class="kml-name fl">
                          <span>{{v.name}}</span>
                          <span class="huiColor">可用额度:<i> {{v.quota}}</i></span>
                      </div>
                      <div class="fl kml-pay clearfix">
                          <span class="copy-link" v-for="(vv,index1) in v.contact" :key="index1" @click="copyLink('copy-link',vv.title)" data-clipboard-action="copy" :data-clipboard-text="vv.value">
                              <i class="pay-icon"><img v-lazy="vv.icon" alt=""></i>
                              <i class="huiColor">{{vv.title}}</i>
                          </span>
                      </div>
                  </li>
              </ul>
          </div>
        </myScroll>

        <!-- 弹窗 -->
        <div class="copy-cg" v-show="tsBox">
            <div class="copy-box">
                <p>已复制联系方式</p>
                <p>请前往<i>{{txt}}</i>添加联系</p>
            </div>
        </div>
        <!-- 充值说明入口 -->
        <div class="explain-icon" @click="explain = true"></div>
        <!-- 充值说明盒子 -->
        <div class="explain-box" v-show="explain">
            <div class="explain-con">
                <i @click="explain = false"></i>
                <h3>充值说明</h3>
                <p>1.代理只负责卡密销售，如果您有其他问题，请联系我们在线客服处理。代理如果骚扰或推荐您到其他平台，欢迎举报，举报属实奖励5千元。</p>
                <p>2.点击图标，系统自动复制对应（支付宝，qq、微信）账号，打开对应（支付宝，qq、微信）账号，添加好友购买。</p>
                <p>3.代理人员会提供，账号密码，返回客户端输入账号密码充值。</p>
                <p>4.充值完成，提示充值成功，返回钱包页面查看金额。</p>
                <p>5.代理人员不定期更换，为避免不必要的损失， 每次支付请到平台提单，以官方为准，谢谢！</p>
            </div>
        </div>
        
    </div>
</template>

<script>
    import headerOne from "../../components/headerOne";
    import myScroll from "../../components/myScroll";

    export default {
        name: "kmRechargeList",
        components:{
            headerOne,myScroll
        },
        data(){
            return{
              ksList:[],//卡商列表
              txt:'支付宝',
              tsBox:false,//提示Sao chép thành công
              explain:false,//说明盒子
            }
        },
        created() {
            this.getKSList();
        },
        methods:{
          getKSList(){
              this.$http.get(this.versionLive2+"Recharge/getcardlist").then(res=>{
                  if(res && res.data.code==1){
                      this.ksList = res.data.data;
                      console.log(this.ksList)
                  }
              })
          },
          copyLink(className,name) {
                this.txt = name.substring(0,name.length-2);
                let _this = this;
                let clipboard = new this.clipboard("."+className);
                clipboard.on('success', function () {
                    // console.log(1122)
                    _this.tsBox = true;
                    setInterval(()=>{
                      _this.tsBox = false;
                    },2000);
                });
                clipboard.on('error', function () {
                    _this.$vux.toast.text(' Sao chép không thành công, vui lòng thử lại sau');
                });
          }
        }
    }
</script>

<style scoped lang="less">
    .rem(@name,@px){
            @{name}:unit(@px/75,rem)
    }
    .explain-icon{
        position: fixed;
        .rem(top,30);
        .rem(right,40);
        z-index: 2;
        width:0.4rem;
        height: 0.4rem;
        background: url('../../assets/images/extend/explain-icon.png')no-repeat;
        background-size: contain;
    }
    .explain-box{
        position: fixed;
        width: 100%;
        height: 100vh;
        z-index: 3;
        left: 0;
        top: 0;
        background: rgba(0,0,0,0.3);
        .explain-con{
            width: 84%;
            border-radius: 10px;
            background-color: #fff;
            position: fixed;
            top: 50%;
            margin-top: -50%;
            left: 50%;
            transform: translateX(-50%);
            .rem(padding-bottom,70);
            i{
                position: absolute;
                right: 0.26666rem;
                top: 0.26666rem;
                display: block;
                .rem(width,25);
                .rem(height,25);
                background: url('../../assets/images/extend/km-close-icon.png')no-repeat;
                background-size: contain;
            }
            p{
                width: 80.15%;
                margin: 0 auto;
                .rem(font-size,24);
                .rem(line-height,42);
            }
            h3{
                font-weight: bold;
                text-align: center;
                .rem(font-size,30);
                .rem(margin-bottom,39);
                .rem(margin-top,59);
            }
        }
    }
    .km-rechargeList{
        background: #fff;
        ul{
            li{
                background: #fff;
                .rem(margin-bottom,10);
                .rem(height,130);
                .rem(padding-top,33);
                .kml-name{
                    width: 29%;
                    .rem(margin-left,39);
                    // margin-right: 4%;
                    overflow: hidden;
                    /*文本不会换行*/
                    white-space: nowrap;
                    /*当文本溢出包含元素时，以省略号表示超出的文本*/
                    text-overflow: ellipsis;
                    >span{
                        display: block;
                        &:nth-child(1){
                            .rem(font-size,24);
                            .rem(margin-bottom,20);
                        }
                        &:nth-child(2){
                            .rem(font-size,20);
                        }
                        overflow: hidden;
                        /*文本不会换行*/
                        white-space: nowrap;
                        /*当文本溢出包含元素时，以省略号表示超出的文本*/
                        text-overflow: ellipsis;
                    }
                    i{
                        color: #F73B3B;
                    }
                }
                .kml-pay{
                    width: 65%;
                    // .rem(margin-right,33);
                    >span{
                        display: block;
                        float: left;
                        width: 33.33%;
                        text-align: center;
                    }
                    i{
                        display: block;
                        .rem(font-size,20);
                        &.pay-icon{
                            .rem(height,43);
                            .rem(width,50);
                            margin: 0 auto 0.18rem auto;
                            img{
                                height: 100%;
                                width: auto;
                            }
                        }
                    }
                }
            }
        }
    }
    .copy-cg{
        position: fixed;
        left: 0;
        top: 0;
        background: rgba(0,0,0,0.3);
        width: 100%;
        height: 100vh;
        z-index: 3;
        .copy-box{
            background-color: #fff;
            position: fixed;
            left: 50%;
            transform: translateX(-50%);
            top: 50%;
            margin-top: -25%;
            .rem(width,340);
            .rem(height, 120);
            border-radius: 5px;
            text-align: center;
            .rem(font-size,24);
            padding-top: 3%;
            i{
                color: #F73B3B;
            }
        }
    }

</style>