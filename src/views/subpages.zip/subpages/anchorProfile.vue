<template>
  <div id="guess">
    <!-- <div v-if="isScroll" class="header" @click="goTop">
      主播信息
    </div> -->
    <myScroll
      :top="0"
      :bottom="0"
      ref="listWrapperL"
      :isDown="true"
      :isLoad="isL"
      v-on:func="reLoad"
      :isUp="isUpFlag"
      :isloadUp="isLup"
    >
      <div class="anchorProfile">
        <!-- 1.0 -->
        <!-- <div class="header1">
          <div
            class="tou"
            v-bind:style="{
              'background-image': 'url(' + infoList.avatar + ')',
              'background-repeat': 'no-repeat',
              'background-size': 'cover'
            }"
          >
            <div class="tou_tou">
              <a href="javascript:;" @click="$router.go(-1)" class="go-back">
                <div class="go"></div>
              </a>
              <div class="info_info clearfix">
                <div class="in_left fl">
                  <div class="photo_new">
                    <img v-lazy="infoList.avatar" alt />
                  </div>
                  <div class="zhubo">主播</div>
                </div>
                <div class="in_right fl">
                  <div class="clearfix" style="margin-bottom: 0.22rem;">
                    <div class="nickname fl">{{ infoList.nickname }}</div>
                    <router-link :to="'/chat/' + id" class="fl">
                      <div
                        :class="
                          infoList.liveStatus == 1 ? 'zhibojian' : 'zhibojian2'
                        "
                      >
                        <span style="padding-left:10px;">直播间</span>
                      </div>
                    </router-link>
                  </div>
                  <div class="qianming" v-if="infoList.sign">
                    {{ infoList.sign }}
                  </div>
                  <div class="qianming" v-else>
                    该主播很懒，还没有设置签名哦！
                  </div>
                  <div class="tagss clearfix">
                    <div
                      :class="infoList.sex == 0 ? 'age' : 'age_nan_1'"
                      v-if="
                        infoList.age == 0 ||
                          infoList.age == '' ||
                          infoList.age == null
                      "
                      style="float: left;"
                    ></div>
                    <div
                      :class="infoList.sex == 0 ? 'age_nv' : 'age_nan'"
                      v-else
                      style="float: left;"
                    >
                      {{ infoList.age }}
                    </div>
                    <div class="level fl" v-if="infoList.level">
                      {{ infoList.level }}
                    </div>
                    <div class="level fl" v-else>1</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="wei clearfix">
            <div class="isFollow fl">
              <span class="sp">{{ infoList.follow_num }}</span>
              <span>关注</span>
            </div>
            <div class="isFans fl">
              <span class="sp">{{ infoList.fans }}</span>
              <span>粉丝</span>
            </div>
            <div
              class="follow1 fr"
              v-if="infoList.isFollow === false"
              @click="getIsFollow"
            >
              关注
            </div>
            <div class="follow fr" v-else @click="getIsFollow">已关注</div>
          </div>
        </div> -->
        <!-- <div class="bg clearfix">
            <a href="javascript:;" @click="$router.go(-1)" class="go-back">
              <div class="go fl"></div>
            </a>
            <div class="info_left">
              <div class="photo">
                <img v-lazy="infoList.avatar" alt />
              </div>
              <div class="zubo">主播</div>
            </div>
            <router-link :to="'/chat/'+id" v-if="infoList.liveStatus == 1">
              <div class="zhibo fr" >
                <span>直播间</span>
              </div>
            </router-link>
            <div class="zhibo1 fr" v-else>
              <span hidden>直播间</span>
            </div>
          </div>
          <div class="info">
            <div class="photo_11">
              <div class="photo">
                <img v-lazy="infoList.avatar" alt />
              </div>
              <div class="zubo">主播</div>
            </div>
            <div class="name_box clearfix">
              <div class="name fl color_bl">{{infoList.nickname}}</div>
              <div class="gender_woman clearfix fl" v-if="infoList.sex == 0">
                <div v-if="infoList.age">{{infoList.age}}</div>
                <div v-else>未填</div>
              </div>
              <div class="gender_man clearfix fl" v-else-if="infoList.sex == 1">
                <div v-if="infoList.age">{{infoList.age}}</div>
                <div v-else>未填</div>
              </div>
  
            </div>
            <div class="qianMing color_h" v-html="infoList.sign">{{infoList.sign}}</div>
            <div class="follow_num color_h clearfix">
              <div class="fans fl">
                <span
                  class="color_bl"
                  style="margin-right: 0.18rem;font-size: 0.42rem;"
                >{{infoList.fans}}</span>
                粉丝
              </div>
              <div class="follow fr" v-if="infoList.isFollow === false" @click="getIsFollow">关注</div>
              <div
                class="follow_g fr"
                v-else-if="infoList.isFollow === true"
                @click="getIsFollow"
              >已关注</div>
            </div>
          </div>-->
        <!-- <a href="javascript:;" @click="$router.go(-1)" class="go-back">
            <div class="go fl"></div>
          </a>-->
        <!-- <div class="dj_1"> -->
        <!-- <div class="bj"  ></div> -->
        <!-- </div>      -->

        <!-- 1.1 -->
        <div class="head">
          <div class="headCon">
            <div class="head-box clearfix">
              <div class="goBack fl" @click="$router.go(-1)">
                <img src="../../assets/images/white-back-icon.png" alt />
              </div>
              <router-link router-link :to="'/chat/' + id"
                ><div class="fr zhibo-box"></div
              ></router-link>
            </div>
            <div class="user-box clearfix">
              <div class="fl userName">
                {{ infoList.nickname ? infoList.nickname : "昵称" }}
              </div>
              <div class="fl " :class="infoList.sex == 0 ?'user-gender' : 'user-gender1'"></div>
              <div class="fl user-age">
                {{ infoList.age ? infoList.age : "0" }}
              </div>
              <div class="fl user-level">
                {{ infoList.level ? infoList.level : "0" }}
              </div>
            </div>
            <div class="prf">
              {{ infoList.sign ? infoList.sign : "这个人很懒，什么都没有留下" }}
            </div>
            <div class="userId">
              房间号：{{ infoList.anchor_id ? infoList.anchor_id : "100001" }}
            </div>
          </div>
        </div>
        <div class="userInfo">
          关注
          <span>{{ infoList.follow_num ? infoList.follow_num : "0" }}</span
          >粉丝 <span>{{ infoList.fans ? infoList.fans : "0" }}</span
          >获赞
          <span>{{ infoList.zan ? infoList.zan : "0" }}</span>
          <div class="tx">
            <div class="tx_1" :class="infoList.liveStatus == 0 ? 'border' : ''">
              <img v-lazy="infoList.avatar" alt />
            </div>
            <div :class="infoList.liveStatus == 1 ? 'circle' : ''"></div>
            <div :class="infoList.liveStatus == 1 ? 'circle' : ''"></div>
            <div :class="infoList.liveStatus == 1 ? 'circle' : ''"></div>
            <a>主播</a>
          </div>
          <!-- <div class="circle">1</div>
          <div class="circle">1ss</div>
          <div class="circle">1s</div> -->
        </div>
        <div class="tab_box" ref="boxItem">
          <tab
            class="tab"
            active-color="#333"
            custom-bar-width="10%"
            disabled-color="#999"
            bar-active-color="#FF513E"
          >
            <!-- <tab-item selected v-for="(item, index) in tabList" :key="index" @on-item-click="onItemClick(index)">
              {{item}}
            </tab-item>-->
            <tab-item selected @on-item-click="onItemClick(0)">资料</tab-item>
            <tab-item @on-item-click="onItemClick(1)">动态</tab-item>
          </tab>
          <!-- <myScroll :top="9.3" :bottom="0" ref="scrollWrapper" :isDown="true" :isLoad="isL" v-on:func="reLoad" :isUp="isUpFlag" :isloadUp="isLup"> -->
          <div class="currentView">
            <!--资料-->
            <div class="ziliao" v-show="index == 0">
              <div class="APInfo">
                <div class="apiTit clearfix">
                  <div class="img fl">
                    <i class="icon icon1"></i>
                    <!-- <img src="../../assets/images/anchorP/4_04-min.png" alt /> -->
                  </div>
                  <div class="color_bl tit_text fl">主播信息 </div>
                </div>
                <div class="list">
                  <ul>
                    <li class="clearfix zb_cai">
                      <span class="color_h fl zb_cai_1">擅长彩种 :</span>
                      <div
                        class="fl"
                        v-for="(vvv, index2) in infoList.lottery"
                        :key="index2"
                      >
                        {{ vvv.name }}
                      </div>
                      <!-- <div class="fl">江苏快三</div> -->
                    </li>
                    <li class="clearfix">
                      <span class="color_h fl zb_tag_2">主播标签 :</span>
                      <div
                        class="zb_tag clearfix fl"
                        v-for="(vv, index1) in infoList.tagList"
                        :key="index1"
                      >
                        <div class="zb_tag_1 fl">
                          <img v-lazy="vv.icon" alt />
                        </div>
                        <div class="fl">{{ vv.title }}</div>
                      </div>
                    </li>
                    <li>
                      <span class="color_h">婚姻状态 :</span>
                      <span>{{infoList.marry ? infoList.marry : '未婚' }}</span>
                    </li>
                    <li>
                      <span class="color_h">播放时长 :</span>
                      <span style=" font-family: number2;"
                        >{{ infoList.duration }} 分钟</span
                      >
                    </li>
                    <li>
                      <span class="color_h" style>开播时间 :</span>
                    
                      <span
                        style=" font-family: number2"
                        v-if="infoList.liveStartTime!='' && infoList.liveEndTime!='' && infoList.liveStartTime!=null && infoList.liveEndTime!=null"
                        >{{ infoList.liveStartTime | filterTime1 }} -
                        {{ infoList.liveEndTime | filterTime1 }}</span
                      >
                      <span v-if="infoList.liveStatus==1&&infoList.liveStartTime==null">直播中</span>
                      <span style=" font-family: number2" v-if="infoList.liveStartTime=='' && infoList.liveEndTime=='' && infoList.liveStatus==0">休息中~~</span>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="APInfo APInfo1">
                <div class="apiTit clearfix">
                  <div class="img fl">
                    <i class="icon icon2"></i>
                    <!-- <img src="../../assets/images/anchorP/4_10-min.png" alt /> -->
                  </div>
                  <div class="color_bl tit_text fl">收到礼物</div>
                  <div
                    class="fr"
                    style=" font-family: number2;color:#999999;font-weight: bold"
                  >
                    <span style="font-size:0.3rem">共</span>
                    <span style="font-size:0.3rem;">{{
                      infoList.giftNum
                    }}</span>
                    <span style="font-size:0.3rem">件</span>
                  </div>
                </div>
                <div class="list_2" v-if="infoList.giftList.length">
                  <!-- v-if="infoList.giftList.length" -->
                  <!-- <div
                    class="img_2"
                    v-for="(v, index) in infoList.giftList"
                    :key="index"
                  >
                  <span>{{v.gift_name}}</span><span class="list_liebiao">x{{v.num}}</span>
                    <img v-lazy="v.icon" alt />
                  </div> -->
                  <!--  -->
                  <myScrollX>
                    <div ref="personTab" class="clearfix">
                      <div
                        class=" fl img_2"
                        id="giftLi"
                        v-for="(v, index) in infoList.giftList"
                        :key="index"
                        :class="bgcolor[index % 4]"
                      >
                        <span>{{ v.gift_name }}</span
                        ><span class="list_liebiao">x{{ v.num }}</span>
                      </div>
                    </div>
                  </myScrollX>
                </div>
                <!-- 没有礼物显示 -->
                <div
                  class="list_2 list_2_2"
                  v-else
                  style="color: #cccccc;font-size：0.3rem!important;"
                >
                  为主播送上第一份礼物吧~
                </div>
              </div>
              <div class="record">
                <div class="recordTit clearfix">
                  <div class="img fl">
                    <i class="icon icon3"></i>
                    <!-- <img src="../../assets/images/anchorP/4_09-min.png" alt /> -->
                  </div>
                  <div class="color_bl tit_text fl">直播记录</div>
                </div>
                <div class="list_4">
                  <div v-if="infoList.live_record.length">
                    <!--<div >-->
                    <ul class="color_h clearfix">
                      <li
                        class="clearfix"
                        v-for="(re, index4) in infoList.live_record"
                        :key="index4"
                      >
                        <span class="record_1 color_h">{{ re.name }}:</span>
                        <span class="record_2 color_h">{{ re.tip }}</span>
                        <span class="record_3 color_h">{{
                          re.startTime | formatDate1
                        }}</span>
                        <span class="record_4 color_h">{{
                          re.startTime | filterTime
                        }}</span>
                      </li>
                    </ul>
                  </div>
                  <!-- 没有直播记录显示 -->
                  <div
                    v-else
                    style="color: #cccccc;font-size：0.3rem!important"
                    class="list_4_1"
                  >
                    主播暂无直播记录~
                  </div>
                </div>
              </div>
            </div>
            <div class="footer" v-show="index == 0">我是有底线滴 ~~</div>
            <!--动态-->
            <div
              class="dongtai"
              v-show="index == 1"
              v-if="dynamicList.length > 0"
            >
              <TrendDt
                v-if="dynamicList.length"
                :dataList="dynamicList"
              ></TrendDt>

              <div class="footer1" v-if="deadline">我是有底线滴 ~~</div>
            </div>
            <div class="dongtai" v-else v-show="index == 1">
              <div style="text-align: center;color: #cccccc;margin:49% auto;">
                主播暂时还未发表动态！
              </div>
            </div>
          </div>
          <!-- </myScroll> -->
        </div>
      </div>
      <!-- <div class="follow-yi">
        <i></i>
        <span>关注</span>
      </div> -->
    </myScroll>
    <div
      class="follow-yi"
      @click="getIsFollow"
      v-if="infoList.isFollow == false"
    >
      <div>关 注</div>
    </div>
    <div
      class="follow-yii"
      @click="getIsFollow"
      v-if="infoList.isFollow == true"
    >
      <div>已关注</div>
    </div>
  </div>
</template>

<script>
import { mapState , mapMutations} from "vuex";
import { Tab, TabItem } from "vux";
import myScroll from "../../components/myScroll.vue";
import { log } from "util";
import myScrollX from "../../components/myScrollX.vue"; //横向滚动
import TrendDt from "../../components/trendsDt.vue";
export default {
  name: "anchorProfile",
  components: {
    Tab,
    TabItem,
    myScroll,
    myScrollX,
    TrendDt
  },
  //   时间格式
  filters: {
    formatDate1(time) {
      let date = new Date(time * 1000);
      let y = date.getFullYear(); // 年
      let M = date.getMonth() + 1;
      M = M < 10 ? "0" + M : M; // 月
      let D = date.getDate();
      D = D < 10 ? "0" + D : D; // 日
      let hh = date.getHours();
      hh = hh < 10 ? "0" + hh : hh; // 时
      let mm = date.getMinutes();
      mm = mm < 10 ? "0" + mm : mm;
      return y + "-" + M + "-" + D;
    },
    filterTime(time) {
      if (!time) return;
      let t = new Date(time * 1000);
      let h = t.getHours() >= 10 ? t.getHours() : "0" + t.getHours();
      let min = t.getMinutes() >= 10 ? t.getMinutes() : "0" + t.getMinutes();
      return h + ":" + min;
    },
    filterTime1(time) {
      if (!time) return;
      let t = new Date(time * 1000);
      let h = t.getHours() >= 10 ? t.getHours() : "0" + t.getHours();
      let min = t.getMinutes() >= 10 ? t.getMinutes() : "0" + t.getMinutes();
      let hAm = h < 12 ? h + ":" + min + "AM" : h - 12 + ":" + min + "PM";
      let h24 = h+':'+min
      return h24;
    }
  },

  data() {
    return {
      infoList: {
        anchor_id: 0, //主播ID
        nickname: "", //主播昵称
        fans: 0, //主播粉丝数
        liveStartTime: "", //直播开始时间
        liveEndTime: "", //直播结束时间
        avatar: "", //主播头像
        giftList: {}, //礼物图片
        giftNum: 0, //礼物数量
        tagList: [], //标签
        gray: true,
        live_record: [], //直播记录
        liveStatus: 0, //直播状态
        sign: "", //签名
      },
      dynamicList: {
        // id: 0,
        // intro: ""
        // isZan:false
      }, //动态列表
      dynamicList1: [], //空动态列表
      index: 0,
      time: "",
      // tabList: ["资 料", "动 态"],
      id: this.$route.params.id, //主播id
      userId: this.$store.state.userinfo.user_id, //用户id
      lasttime: "",
      limit: 3,
      page: 1,
      isL: false, //是否显示 下拉刷新的组件
      isLup: false, //是否显示 上拉加载更多的组件
      deadline: false, //显示我是有底线的
      pullUp: true, //上拉组件提示
      isMorePage: false, //判断是否有下一页
      isUpFlag: false, //是否开启上拉加载更多
      tabIndex: true,
      playList: {},
      isScroll: false, //显示固定元素
      scrollY: "",
      giftListLength: "",
      bgcolor: ["a1", "a2", "a3", "a4"]
    };
  },
  created() {},
  mounted() {
    this.init(); //主页面
    this.getDynamic(); //动态页面
    setTimeout(() => {
      this.initScroll();
    }, 600);
    // this.ScrollX();
  },
  watch: {
    index(n) {
      if (n == 0) {
        this.isMorePage = false;
        this.isUpFlag = false;
      } else if (n == 1) {
        this.isMorePage = true;
        this.isUpFlag = true;
      }
    },
    infoList: function() {
      this.$nextTick(() => {
        this.ScrollX();
      });
    }
    // data() {
    //   this.Myscroll = new BScroll(this.$refs.wrapper, {
    //     //                    pullUpLoad:true,
    //     startY: this.satrY, //调用上次加载后底部y轴的位置    ---**重点** starY在data里面初始值设置为0
    //     scrollY: this.isScrollY,
    //   });

    //   console.log(startY)
    // }
  },
  computed: {
    ...mapState(["codeToken"])
  },
  methods: {
    //获取主播信息
    ...mapMutations(["SETUSERTOKEN"]),
    init() {
      this.$http
        .get(
          this.versionLive2 +
            "live/get_anchor_info/?anchor_id=" +
            this.id +
            "&user_id=" +
            this.userId,
          {}
        )
        .then(res => {
          if (res && res.data.code == 1) {
            this.infoList = res.data.data;
            // this.infoList.giftList = res.data.data[6];
            this.giftListLength = this.infoList.giftList.length;
            // console.log(this.giftListLength);
            this.isMorePage = false;
          }
        });
    },

    destroy() {
      this.$refs.listWrapperL.Myscroll.destroy();
    },
    destroyed() {
      this.$refs.listWrapperL.Myscroll &&
        this.$refs.listWrapperL.Myscroll.destroy();
    },
    initScroll() {
      this.$nextTick(() => {
        if (!this.$refs.listWrapperL) {
          return;
        }
        this.$refs.listWrapperL.Myscroll.on("scroll", pos => {
          var tops = this.$refs.boxItem.offsetTop;

          // 使用abs绝对值（否则 pos.y拿到值是负数）
          this.scrollY = Math.abs(Math.round(pos.y));
          if (this.scrollY >= tops) {
            this.isScroll = true;
          } else {
            this.isScroll = false;
          }
        });
      });
    },
    ScrollX() {
      let allLi = document.querySelectorAll("#giftLi");
      let sum = 0;
      for (var i = 0; i < allLi.length; i++) {
        sum += allLi[i].offsetWidth;
        // console.log(allLi[i].offsetWidth);
        // console.log(sum)
      }
      let width = sum + this.infoList.giftList.length * 15;
      // console.log(this.infoList.giftList.length)
      // width = width + 8;
      // console.log(width);
      this.$refs.personTab.style.width = width + "px";
    },
    // tab切换
    onItemClick(index) {
      // if(index==1){
      //   // this.$vux.confirm.show({
      //   //             title:'提示',
      //   //             content:'<p style="font-size: 14px;padding-bottom: .2rem;padding-top: .2rem;color: #445779;font-weight: 500">当前账号为游客试玩账号</p><p style="font-size: 14px;padding-bottom: .2rem;color: #445779;font-weight: 500">不可以执行此操作</p><p style="font-size: 14px;padding-bottom: .2rem;color: #445779;font-weight: 500">请Đăng ký正式账号</p>',
      //   //             confirmText:"Xác nhận",
      //   //             showCancelButton:false,
      //   //             onConfirm : () => {
                       
      //   //             }
      //   //         });
      //   this.$swBox({
      //       title: "提示",
      //       content: "Hiện nay hệ thống chỉ mở chơi thử trò chơi sổ xố, nếu có yêu cầu khác mời quý khách đăng nhập tài khoản chính thức。",
      //       leftBtn: "登录",
      //       rightBtn:'Đăng ký',
      //       clickL: () => {
      //           this.SETUSERTOKEN('')
      //           this.$router.push('/login');
      //       },
      //       clickR: () => {
      //           this.SETUSERTOKEN('')
      //           if(this.noticeType==1){
      //               this.$router.push('/register');
                    
      //           }else{
      //               this.$router.push('/RegisterDl');
                    
      //           }
      //       }
      //   });
      //           return
      // }
      this.index = index;
    },
    // 关注
    getIsFollow() {
      if (!this.codeToken) {
        return this.$popup({
          title: "我是标题",
          content: "我是内容",
          btnText: "我是按钮",
          click: () => {
            this.isLogin = false;
          }
        });
      }
      if(this.$store.state.userinfo.user_id<0){
        // this.$vux.confirm.show({
        //             title:'提示',
        //             content:'<p style="font-size: 14px;padding-bottom: .2rem;padding-top: .2rem;color: #445779;font-weight: 500">当前账号为游客试玩账号</p><p style="font-size: 14px;padding-bottom: .2rem;color: #445779;font-weight: 500">不可以执行此操作</p><p style="font-size: 14px;padding-bottom: .2rem;color: #445779;font-weight: 500">请Đăng ký正式账号</p>',
        //             confirmText:"Xác nhận",
        //             showCancelButton:false,
        //             onConfirm : () => {
                       
        //             }
        //         });
        this.$swBox({
            title: "提示",
            content: "Hiện nay hệ thống chỉ mở chơi thử trò chơi sổ xố, nếu có yêu cầu khác mời quý khách đăng nhập tài khoản chính thức。",
            leftBtn: "登录",
            rightBtn:'Đăng ký',
            clickL: () => {
                this.SETUSERTOKEN('')
                this.$router.push('/login');
            },
            clickR: () => {
                this.SETUSERTOKEN('')
                if(this.noticeType==1){
                    this.$router.push('/register');
                    
                }else{
                    this.$router.push('/RegisterDl');
                    
                }
            }
        });
        return
      } 
      this.$http
        .post(this.versionLive2 + "live/follow/?token=" + this.codeToken, {
          anchor_id: this.id,
          user_id: this.userId
        })
        .then(res => {
          if (this.infoList.isFollow == false) {
            this.infoList.isFollow = true;
            this.infoList.fans = this.infoList.fans + 1;
          } else {
            this.infoList.isFollow = false;
            this.infoList.fans = this.infoList.fans - 1;
          }
        });
    },
    //获取动态
    getDynamic() {
      if(this.$store.state.userinfo.user_id<0) return
      this.$http
        .get(
          this.versionLive2 +
            "live/get_anchor_dynamic/?anchor_id=" +
            this.id +
            "&lasttime=" +
            this.lasttime +
            "&page=" +
            this.page +
            "&limit=" +
            this.limit +
            "&user_id=" +
            this.userId,
          {
            // anchor_id: this.id,
            // lasttime: this.lasttime,
            // page: this.page,
            // limit: this.limit,
            // user_id:this.userId
          }
        )
        .then(res => {
          if (res && res.data.code == 1) {
            this.gray = false;
            this.dynamicList = res.data.data || [];
            this.playList.dynamicList = this.dynamicList;

            this.isL = false;
            this.page = 1;
            this.deadline = false;
            this.$previewRefresh();
          }
        });
    },
    //动态点赞
    DynamicLike(index6) {
      if (!this.codeToken) {
        // 如果没有登录提示请登录
        this.$popup({
          title: "我是标题",
          content: "我是内容",
          btnText: "我是按钮",
          click: () => {
            this.isLogin = false;
          }
        });
      } else {
        if(this.$store.state.userinfo.user_id<0){
          // this.$vux.confirm.show({
          //           title:'提示',
          //           content:'<p style="font-size: 14px;padding-bottom: .2rem;padding-top: .2rem;color: #445779;font-weight: 500">当前账号为游客试玩账号</p><p style="font-size: 14px;padding-bottom: .2rem;color: #445779;font-weight: 500">不可以执行此操作</p><p style="font-size: 14px;padding-bottom: .2rem;color: #445779;font-weight: 500">请Đăng ký正式账号</p>',
          //           confirmText:"Xác nhận",
          //           showCancelButton:false,
          //           onConfirm : () => {
                       
          //           }
          //       });
        this.$swBox({
            title: "提示",
            content: "Hiện nay hệ thống chỉ mở chơi thử trò chơi sổ xố, nếu có yêu cầu khác mời quý khách đăng nhập tài khoản chính thức。",
            leftBtn: "登录",
            rightBtn:'Đăng ký',
            clickL: () => {
                this.SETUSERTOKEN('')
                this.$router.push('/login');
            },
            clickR: () => {
                this.SETUSERTOKEN('')
                if(this.noticeType==1){
                    this.$router.push('/register');
                    
                }else{
                    this.$router.push('/RegisterDl');
                    
                }
            }
        });
                return
        }
        // 如果登录执行点赞接口
        this.$http
          .post(this.versionLive2 + "live/dynamic_like/", {
            dynamic_id: this.dynamicList[index6].id,
            user_id: this.userId
          })
          .then(res => {
            if (res && res.data.code == 1) {
              if (this.dynamicList[index6].isZan == true) {
                this.dynamicList[index6].isZan = false;
                this.dynamicList[index6].zans =
                  this.dynamicList[index6].zans - 1;
              } else if (this.dynamicList[index6].isZan == false) {
                this.dynamicList[index6].isZan = true;
                this.dynamicList[index6].zans =
                  this.dynamicList[index6].zans + 1;
              }
            }
          });
      }
    },
    // 分页
    reLoad(data) {
      // 判断是否上拉事件
      if (data == "down") {
        this.isL = true;
        this.getDynamic();
      } else if (data == "up") {
        // 如果是执行分页事件
        this.loadMore();
      }
    },
    async loadMore(id) {
      // let i = this.index;
      // if(i == 1) {
      //     this.isMorePage = false;
      //     this.isUpFlag = false;
      //     this.deadline = true;
      //     return
      // };
      if (!this.isMorePage) return; //判断是否有更多数据如果没有直接返回
      //节流阀
      if (!this.isUpFlag) return;
      this.pullUp = true;
      this.isUpFlag = true;
      this.isLup = true;
      this.page++;
      // 请求分页接口页数比之前加一
      let res = await this.$http.get(
        this.versionLive2 +
          "live/get_anchor_dynamic/?anchor_id=" +
          this.id +
          "&lasttime=" +
          this.lasttime +
          "&page=" +
          this.page +
          "&limit=" +
          this.limit +
          "&user_id=" +
          this.userId,
        {}
      );
      this.isLup = false;
      this.page = 1;
      if (res && res.data.code == 1) {
        if (res.data.data.length > 0) {
          // 如果有分页显示
          this.isMorePage = true;
          this.isUpFlag = true;
          this.deadline = false;
        } else if (res.data.data.length <= 0) {
          // 如果没有分页显示
          this.isMorePage = false;
          this.isUpFlag = false;
          this.deadline = true;
        }
        this.dynamicList = this.dynamicList.concat(res.data.data); // 合并现在请求的
        // this.dynamicList = this.dynamicList.concat(res.data.data); // 合并现在请求的
        this.playList.dynamicList = this.dynamicList;
        setTimeout(() => {
          this.$refs.listWrapperL.refresh(); //重新计算高度，刷新滚动条
        }, 20);
        this.$previewRefresh();
      }
    },
    goTop() {
      this.$refs.listWrapperL.Myscroll.scrollTo(0, 0, 500);
      this.isScroll = false;
    }
  }
};
</script>

<style scoped lang="less">
.a1 {
  background-color: #ffefed !important;
}
.a2 {
  background-color: #fff4e3 !important;
}
.a3 {
  background-color: #ffece0 !important;
}
.a4 {
  background-color: #e9f8ff !important;
}
.header {
  text-align: center;
  position: fixed;
  top: 0;
  left: 0;
}
.tab_box {
  margin-top: 0.27rem;
  background: #fff;
}
.ziliao {
  // box-shadow: 1px 5px 10px #f5f5f5;
  // width: 95%;
  width: 92%;
  // margin: 0.1rem auto 0;
  padding-top: 0.1rem;
  margin: 0 auto;
  border-radius: 5px;
  background: #fff;
}
.anchorProfile .tab_box .vux-tab-item {
  
  font-size: 0.41rem;
  position: relative;
}
.anchorProfile .go-back {
  display: block;
  width: 1rem;
  height: 1rem;
  position: absolute;
  left: 0.2rem;
  top: 0.3rem;
}
.anchorProfile .tab_box .vux-tab-selected {
  font-weight: bold;
}
// .anchorProfile .tab_box .vux-tab-item:first-of-type:after {
//   position: absolute;
//   content: "";
//   width: 1px;
//   background: #eee;
//   height: 0.3rem;
//   right: 0;
//   top: 0.35rem;
// }

.footer {
  color: #cccccc;
  text-align: center;
  padding-bottom: 6.7%;
  padding-top: 6.7%;
  background: #fff;
  width: 95%;
  margin: 0 auto;
}
.footer1 {
  color: #cccccc;
  text-align: center;
  padding-bottom: 6.7%;
  padding-top: 6.7%;
  background: #fff;
  // width: 95%;
  margin: 0 auto;
}
.color_bl {
  font-family: "number2";
  font-weight: 600;
  color: #445779;
}
.fw {
  font-family: "number2";
}
.color_h {
  color: #999999;
}
.anchorProfile {
  font-size: 0.3rem;
  background: #f7f7f7;
  .header1 {
    width: 100%;
    line-height: 0.5rem;
    background-color: #fff;
    height: 5.6rem;
    .tou {
      height: 4.278rem;
      overflow: hidden;
      background-color: #ccc;
      background-position: center;
      .tou_tou {
        background: rgba(0, 0, 0, 0.4);
        width: 100%;
        height: 100%;
      }
      .info_info {
        padding-top: 1.52rem;
        color: #fff;
        .in_left {
          position: relative;
          width: 17.33%;
          margin-right: 5%;
          // margin-top: 1.52rem;
          // margin-left: 0.3rem;
          margin-left: 4%;
          .photo_new {
            height: 1.9rem;
            width: 1.9rem;
            border-radius: 50%;
            overflow: hidden;
            border: 3px solid #fff;
            img {
              width: auto;
              height: 100%;
            }
          }
          .zhubo {
            position: absolute;
            background-color: #ff513e;
            color: #fff;
            width: 45.15%;
            text-align: center;
            bottom: 0;
            right: -5%;
            border-radius: 10px 0 10px 0;
          }
        }
        .in_right {
          .nickname {
            font-size: 0.44rem;
            font-family: "number2";
            margin-right: 0.12rem;
            text-overflow: ellipsis;
            max-width: 3rem;
            overflow: hidden;
            white-space: nowrap;
          }
          .qianming {
            text-overflow: ellipsis;
            max-width: 6rem;
            overflow: hidden;
            white-space: nowrap;
          }
          .zhibojian {
            color: #fff;
            float: left;
            text-align: right;
            background: rgba(0, 0, 0, 0.3);
            font-size: 0.3rem;
            line-height: 0.5rem;
            border-radius: 2px;
            overflow: hidden;
            padding: 1px 3px 1px 0.4rem;
            // margin-left: 3%;
            position: relative;
            // width: 1.6rem;
            &:before {
              content: "";
              position: absolute;
              left: 7%;
              top: -2%;
              background: url("../../assets/images/anchorP/zhibo_ing.gif")
                no-repeat center;
              background-size: contain;
              height: 20px;
              width: 15px;
            }
          }
          .zhibojian2 {
            float: left;
            text-align: right;
            background: rgba(0, 0, 0, 0.3);
            font-size: 0.3rem;
            line-height: 0.5rem;
            border-radius: 2px;
            overflow: hidden;
            padding: 1px 3px 1px 0.4rem;
            // margin-left: 3%;
            position: relative;
            color: #fff;
            // width: 1.6rem;
            &:before {
              content: "";
              position: absolute;
              left: 7%;
              top: -2%;
              background: url("../../assets/images/anchorP/zhubo_19.png")
                no-repeat center;
              background-size: contain;
              height: 20px;
              width: 15px;
            }
          }
          .tagss {
            margin-top: 0.22rem;
            .age_nv {
              font-family: "number2";
              float: left !important;
              width: 42px;
              height: 16px;
              text-align: center;
              line-height: 16px;
              background: url("../../assets/images/icon.png") no-repeat;
              background-position: 0% -792.5px;
              background-size: 80px;
              padding-left: 6px;
            }
            .age_nan {
              font-family: "number2";
              float: left !important;
              width: 42px;
              height: 16px;
              text-align: center;
              line-height: 16px;
              background: url("../../assets/images/icon.png") no-repeat;
              background-position: 0% -750px;
              background-size: 80px;
              padding-left: 6px;
            }
            .age_nan_1 {
              float: left !important;
              width: 42px;
              height: 16px;
              text-align: center;
              line-height: 16px;
              background: url("../../assets/images/icon.png") no-repeat;
              background-position: 0% -729px;
              background-size: 80px;
              padding-left: 6px;
            }
            .age {
              float: left !important;
              width: 42px;
              height: 16px;
              text-align: center;
              line-height: 16px;
              background: url("../../assets/images/icon.png") no-repeat;
              background-position: 0% -771.5px;
              background-size: 80px;
              padding-left: 6px;
            }
            .level {
              font-family: "number2";
              float: left !important;
              width: 42px;
              height: 16px;
              text-align: center;
              line-height: 16px;
              background: url("../../assets/images/icon.png") no-repeat;
              background-position: 0% -840.5px;
              background-size: 80px;
              padding-left: 7px;
              margin-left: 0.14rem;
            }
          }
        }
      }
      .go {
        position: relative;
        margin: 6% 5%;
        &:before {
          content: "";
          position: absolute;
          background: url("../../assets/images/withdrawals/baise_fanhui.png")
            no-repeat;
          background-size: contain;
          // width: 0.6rem;
          // height: 0.6rem;
          width: 0.27rem;
          height: 0.51rem;
          color: #fff;
          top: 19%;
          left: 15%;
        }
      }
    }
    .wei {
      width: 94.667%;
      margin: 0 auto;
      font-size: 0.3rem;
      height: 1.34rem;
      line-height: 1.34rem;
      span {
        display: inline-block;
      }
      .isFollow {
        margin-left: 5.7%;
        margin-right: 11%;
        // height: 1.34rem;
        // line-height: 0.34rem;
      }
      .sp {
        font-family: "number2";
        color: #333333;
        font-size: 0.48rem;
      }
      .isFans {
        margin-left: 5.7%;
      }
      .follow1 {
        color: #ff513e;
        font-size: 0.38rem;
        position: relative;
        &:before {
          content: "";
          position: absolute;
          background: url("../../assets/images/icon.png") no-repeat;
          // background-size: 180px;
          // background-position: 0 0px;
          background-size: 80px;
          background-position: 0px -889px;
          top: 38%;
          left: -50%;
          height: 12px;
          width: 12px;
        }
      }
      .follow {
        color: #999999;
        font-size: 0.38rem;
        position: relative;
        &:before {
          content: "";
          position: absolute;
          background: url("../../assets/images/icon.png") no-repeat;
          background-size: 80px;
          background-position: -48px -420px;
          top: 40%;
          left: -35%;
          height: 12px;
          width: 16px;
        }
      }
    }
    .bj {
      overflow: hidden;
      height: 4.278rem;
      width: 100%;
      position: absolute;
      top: 0;
      left: 0;
      opacity: 0.9;
    }
    .zhibo {
      position: relative;
      color: #fe513e;
      background-color: #fff;
      padding-right: 4px;
      padding-top: 1px;
      height: 0.56rem;
      line-height: 0.56rem;
      width: 16.933%;
      // margin: 15% 0% 20% 0;
      margin: 1.27rem 0% 1.8rem 0;
      border-radius: 20px 0 0 20px;
      &:before {
        content: "";
        position: absolute;
        background: url("../../assets/images/member/a1.gif") no-repeat;
        background-size: contain;
        width: 20%;
        height: 100%;
        top: 30%;
        left: 13%;
      }
    }
    .zhibo1 {
      color: #fe513e;
      // background-color: #fff;
      padding-right: 4px;
      padding-top: 1px;
      height: 0.56rem;
      line-height: 0.56rem;
      width: 16.933%;
      // margin: 15% 0% 20% 0;
      margin: 1.27rem 0% 1.8rem 0;
      border-radius: 20px 0 0 20px;
    }
  }
}
.tab_box {
  // background: #fff;
  .tab {
    width: 100%;
    border-bottom: none;
    // margin-left: 3%;
    width: 95%;
    margin: 0 auto;
    background: #eeeeee;
    border-radius: 5px 5px 0 0;
    overflow: hidden;
  }
  .vux-tab-item {
    background: none;
  }
  .APInfo {
    // margin: 5% 6% 4% 5%;
    // margin: 2% 6% 4% 2%;
    // margin: 0% 4% 0% 4%;
    line-height: 0.6rem;
    background: #fff;
    // border-radius: 10px;
    // box-shadow: #f7f7f7 0px 8px 30px;
    padding-top: 4%;
    font-size: 0.35rem;
    // border-top:1px solid #F5F5F5;
    .apiTit {
      // margin-left: 5%;
      .img {
        width: 0.5rem;
        height: 0.5rem;
        margin-right: 2%;
        // margin-top: 0.8%;
        // img {
        //   width: auto;
        //   height: 100%;
        // }
        .icon1 {
          display: inline-block;
          width: 0.59rem;
          height: 0.59rem;
          background: url(../../assets/images/icon.png);
          background-position: 0 4.2rem;
          background-size: 2rem;
        }
        .icon2 {
          display: inline-block;
          width: 0.59rem;
          height: 0.58rem;
          background: url(../../assets/images/icon.png);
          background-position: 0px 8.15rem;
          background-size: 2rem;
        }
      }
      .tit_text {
        font-size: 0.38rem;
        margin-bottom: 2%;
      }
    }
    .list {
      // margin-left: 5%;
      // margin-bottom: 5%;
      ul {
        padding-bottom: 6%;
        li {
          line-height: 0.8rem;
          span {
            display: inline-block;

            &:nth-child(1) {
              text-align: justify;
              text-align-last: justify;
              width: 1.8rem;
              margin-right: 3%;
            }
          }
          .zb_tag_2 {
            margin-right: 4% !important;
          }
          .zb_tag {
            margin-right: 7%;
            .zb_tag_1 {
              width: 24%;
              // margin-top: 5%;
              margin-right: 10%;
              position: relative;
              top: 5%;
              display: block;
              padding-top: 3%;
            }
          }
        }
        .zb_cai {
          div {
            margin-right: 6%;
            &:nth-last-child(1) {
              margin-right: 0;
            }
          }
          .zb_cai_1 {
            margin-right: 4%;
          }
          .zb_cai_2 {
            margin-right: 5%;
          }
        }
      }
      .list_one {
        display: inline-block;
        width: 0.2rem;
        height: 0.2rem;
        background-color: #e54848;
        border-radius: 50%;
        margin-right: 2%;
      }
    }
    .list_2 {
      /*margin-left: 4.5%;*/
      // margin-right: 4.5%;
      margin-top: 6%;
      padding-bottom: 7.5%;
      // margin-left: 4.5%;
      // display: flex;//1.0
      overflow: hidden; //1.0
      .img_2 {
        // width: 18%;
        // width: 1.31rem;
        // height: 1.2rem;
        // display: inline-block;
        // overflow: hidden;
        // margin-right: 4%;
        // width: 1.38rem;
        // flex: 1;
        // width: 20%;//1.0
        // height: 1.2rem; //1.0
        display: inline-block;
        /*margin-right: 4%;*/
        text-align: center;
        padding: 0 0.27rem;
        background: #ffefed;
        border-radius: 100px;
        margin-right: 0.32rem;
        margin-bottom: 0.2rem;
        color: #445779;
        font-size: 0.34rem;
        height: 0.67rem;
        line-height: 0.67rem;
        .list_liebiao {
          font-style: italic;
          font-family: number2;
          color: #ff513e;
          margin-left: 3px;
        }
        img {
          height: 100%;
          width: auto;
        }
      }
    }
    .list_2_2 {
      font-size: 0.3rem;
    }
  }
  .APInfo1 {
    // padding-top: 6.7%;
    .apiTit {
      padding-top: 6.7%;
      // margin-left: 4.5%;
      // margin-right: 4.5%;
      border-top: 1px solid #f5f5f5;
      .tit_text {
        margin-bottom: 0%;
      }
    }
  }
  .record {
    // margin: 2% 6% 4% 2%;
    // margin: 0% 4% 0% 4%;
    line-height: 0.5rem;
    background: #fff;
    border-radius: 10px;
    /*box-shadow: #f7f7f7 0px 8px 30px;*/
    // padding-top: 4%;
    padding-top: 0;
    font-size: 0.35rem;
    .recordTit {
      padding-top: 6.7%;
      // margin-left: 5%;
      margin-right: 4.5%;
      border-top: 1px solid #f5f5f5;
      .img {
        width: 0.598rem;
        height: 0.598rem;
        overflow: hidden;
        // border-radius: 50%;
        margin-right: 2%;
        // margin-top: 0.8%;
        // img {
        //   width: auto;
        //   height: 100%;
        // }
        .icon3 {
          display: inline-block;
          width: 0.598rem;
          height: 0.598rem;
          background: url(../../assets/images/icon.png);
          background-position: 0 5.65rem;
          background-size: 2.1rem;
        }
      }
      .tit_text {
        font-size: 0.38rem;
        margin-top: 1%;
      }
    }
    .list_4 {
      // margin-left: 4.7%;
      margin-right: 4.7%;
      padding-bottom: 2.7%;
      font-size: 0.35rem;
      // border-left: 2px solid  #ccc;
      ul {
        margin-top: 4%;
        li {
          // border-left: 3px solid #d8d8d8;
          padding-bottom: 5%;
          span {
            font-family: "number2";
            color: #000;
            display: inline-block;
            // &:nth-child(2) {
            //   margin-right: 10%;
            // }
            // &:nth-child(3) {
            //   margin-right: 10%;
            // }
            // &:nth-child(1) {
            //   color: #898d92;
            // }
          }
          .record_1 {
            width: 2rem;
            // text-align: center;
            
            text-align: justify;
            text-align-last: justify;
            display: inline-block;
            // width:100%;
            margin-right: 4%;
          }
          .record_2 {
            width: 1.3rem;
            margin-right: 5%;
            text-align: center;
          }
          .record_3 {
            /*width: 2rem;*/
            /*margin-right: .5rem;*/
          }
          .record_4 {
            float: right;
          }
        }
      }
      .list_4_1 {
        font-size: 0.3rem;
        padding-top: 5%;
      }
    }
  }
  .dongtai {
    width: 100%;
    margin: 0 auto;
    // padding-top: 4%;
    padding-bottom: 5.8%;
    background: #fff;
    .dongtai_1 {
      // width: 91.5%;
      margin: auto;
      .dongtai_2 {
        //  width: 91.5%;
        margin: auto;
      }
      ul {
        // width: 91.5%;
        width: 100%;
        margin: auto;
        background: #fff;
        li {
          overflow: hidden;
          margin-bottom: 3.1%;
          // box-shadow: 0px 5px 5px #fafafa;
          border-bottom: 1px solid #f5f5f5;
          // padding: 0 4.2225%;
          padding-top: 3.1%;
          margin: 0 4.2225%;
          &:nth-last-child(1) {
            border: none;
          }
          .dt_photo_1 {
            margin-top: 3.1%;
            width: 100%;

            .dt_photo {
              width: 0.73rem;
              height: 0.73rem;
              padding-top: 0;
              border-radius: 50%;
              overflow: hidden;
              img {
                height: 100%;
                width: auto;
              }
            }
            .dt_name {
              margin-left: 2.3%;
            }
            > div {
              padding-top: 2%;
            }
          }

          > p {
            line-height: 0.4rem;
            font-size: 0.3rem;
            padding: 4.6% 0 4.6%;
          }
          .dt_img {
            box-sizing: border-box;
            display: flex;
            flex-wrap: wrap;
            .dt_img_1 {
              // width: 32%;
              width: 2.78rem;
              height: 2.78rem;
              margin-right: 1%;
              margin-top: 2%;
              border-radius: 5px;
              overflow: hidden;
              img {
                height: 100%;
                width: auto;
                min-width: 2.78rem;
                -webkit-touch-callout: unset;
                pointer-events: unset;
              }
            }

            div {
              margin-bottom: -3px;
            }
          }
          .dt_time {
            width: 100%;
            padding: 4.7% 0 4.7%;
            .dt_follow {
              .dt_icon {
                width: 0.5rem !important;
                height: 0.5rem !important;
                padding-right: 2px;
              }
              .dt_img {
                box-sizing: border-box;
                display: flex;
                flex-wrap: wrap;
                .dt_img_1 {
                  // width: 32%;
                  width: 2.78rem;
                  height: 2.78rem;
                  margin-right: 1%;
                  margin-top: 2%;
                  border-radius: 5px;
                  overflow: hidden;
                  img {
                    height: 100%;
                    width: auto;
                    min-width: 2.78rem;
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  .likesbefore {
    display: inline-block;
    width: 15px;
    text-align: right;
    padding-right: 1em;
    color: #c0c6dc;
    position: relative;
    height: 15px;
    background: url("../../assets/images/anchorP/4_03-min.png") no-repeat;
    background-size: 100%;
    top: 1px;
    top: 2px;
    left: -5px;
  }

  .likesafter {
    display: inline-block !important;
    width: 15px !important;
    text-align: right !important;
    padding-right: 1em !important;
    color: #c0c6dc !important;
    position: relative !important;
    height: 15px !important;
    background: url("../../assets/images/anchorP/4_06-min.png") no-repeat !important;
    background-size: 100% !important;
    top: 1px !important;
    top: 2px !important;
    left: -5px !important;
  }
  .gray {
    color: #bfc8d9;
  }
  .pink {
    color: #ff513e !important;
  }
  .grayHide {
    width: 100%;
    background: #fdfdfd;
    overflow: hidden;
    li {
      background: #ffff;
      width: 94.6%;
      margin: 0.3rem auto 0;
      padding: 0.3rem;
      overflow: hidden;
      .gryhead {
        a:first-child {
          width: 50px;
          height: 50px;
          display: inline-block;
          background: #ededed;
          border-radius: 50%;
        }
        .childwid {
          display: inline-block;
          background: #ededed;
          width: 100px;
          height: 13px;
          border-radius: 3px;
          position: relative;
          top: -18px;
          left: 10px;
        }
        span {
          border-radius: 3px;
          display: inline-block;
          // float: right;
          float: right;
          line-height: 50px;
          /* color: #cccccc; */
          width: 80px;
          height: 13px;
          background: #ededed;
          position: relative;
          top: 19px;
        }
      }
      .bgp {
        height: 15px;
        width: 200px;
        background: #ededed;
        margin-top: 10px;
        border-radius: 3px;
      }
      .imgDIv {
        width: 100%;
        margin-top: 15px;
        overflow: hidden;
        span {
          display: block;
          float: left;
          width: 31%;
          height: 100px;
          background: #ededed;
          margin-left: 10px;
          border-radius: 7px;
        }
        span:first-child {
          margin: 0;
        }
      }
      .botDiv {
        width: 100%;
        overflow: hidden;
        margin-top: 15px;

        span {
          display: block;
          width: 100px;
          height: 15px;
          background: #ededed;
          border-radius: 99px;
        }
      }
    }
  }
}
.head {
  width: 100%;
  height: 4.55rem;
  background: #fff;
  .headCon {
    width: 100%;
    height: 4.55rem;
    background: url("../../assets/images/anchorP/zhubobg.png") no-repeat center;
    background-size: 100% 100%;
    .head-box {
      height: 1.18rem;
      .goBack {
        width: 10%;
        img {
          width: 0.3rem;
          margin: 0.3rem;
        }
      }
      .zhibo-box {
        color: #fff;
        height: 0.515rem;
        // line-height: 0.515rem;
        width: 1.54rem;
        background: url("../../assets/images/anchorP/zhibo-1.1.png") no-repeat
          center;
        background-size: contain;
        margin-top: 0.32rem;
        margin-right: 0.4rem;
      }
    }

    p {
      color: #fff;
      padding-left: 5.3%;
      clear: both;
    }
    .user-box {
      // padding-top: 0.35rem;
      // padding-bottom: 0.15rem;
      // color: #f5f7fa;
      // padding-left: 5.3%;
      padding-bottom: 0.15rem;
      color: #f5f7fa;
      padding-left: 5.3%;
      height: 0.7rem;
      line-height: 0.7rem;
      margin-top: 0.35rem;
      div {
        margin-right: 1.5%;
      }
      .userName {
        font-size: 0.54rem;
      }
      .user-gender {
        width: 0.46rem;
        height: 0.46rem;
        background: url("../../assets/images/chat/host_07.png") no-repeat center;
        background-size: contain;
        margin-top: 0.17rem;
        // font-family:number1 ;
      }
      .user-gender1 {
        width: 0.46rem;
        height: 0.46rem;
        background: url("../../assets/images/chat/gender-man-min (1).png") no-repeat center;
        background-size: contain;
        margin-top: 0.17rem;
        // font-family:number1 ;
      }
      .user-age {
        height: 0.46rem;
        width: 1.2rem;
        background: url("../../assets/images/chat/host_09.png") no-repeat center;
        background-size: contain;
        text-align: center;
        margin-top: 0.17rem;
        line-height: 0.46rem;
        padding-left: 0.28rem;
        font-family: number1;
      }
      .user-level {
        height: 0.46rem;
        width: 1.2rem;
        background: url("../../assets/images/chat/host_11.png") no-repeat center;
        background-size: contain;
        text-align: center;
        margin-top: 0.17rem;
        line-height: 0.46rem;
        padding-left: 0.28rem;
        font-family: number1;
      }
    }
    .userId {
      color: #daa5ff;
      padding-left: 5.3%;
    }
    .prf {
      // font-size: 0.3rem;
      color: #f5f7fa;
      padding-left: 5.3%;
      font-size: 0.35rem;
      height: 0.75rem;
      line-height: 0.75rem;
      max-width: 90%;
      overflow: hidden;
      text-overflow: ellipsis; //溢出用省略号显示
      white-space: nowrap; //溢出不换行
    }
  }
}
.userInfo {
  color: #333333;
  font-size: 0.3rem;
  font-family: unset;
  padding-left: 4%;
  background: #fff;
  height: 1.7rem;
  line-height: 1.3rem;
  // margin-bottom: 0.5rem;
  span {
    font-size: 0.54rem;
    padding: 0 0.4rem 0 0.12rem;
    font-family: number1;
  }
  .tx {
    width: 1.98rem;
    height: 1.98rem;
    // background: #fff;
    border-radius: 50%;
    position: absolute;
    // top: 2.3rem;
    right: 0.75rem;
    text-align: center;
    top: 3.18rem;
    // position: relative;
    // transform: perspective(1000);
    .tx_1 {
      width: 1.98rem;
      height: 1.98rem;
      border-radius: 50%;
      overflow: hidden;
      z-index: 100;
      position: relative;
      // border: 2.5px solid #fff;
      img{
        height: 100%;
        width: auto;
      }
    }

    img {
      // width: 2.7rem;
      // height: 2.7rem;
      // border-radius: 50%;
      // margin-top: 0.15rem;
    }
    a {
      position: absolute;
      bottom: -0.2rem;
      display: block;
      width: 0.8rem;
      line-height: 0.5rem;
      left: 50%;
      transform: translateX(-50%);
      color: #fff;
      height: 0.5rem;
      border-radius: 2px 10px 2px 10px;
      z-index: 100;
      background: -webkit-linear-gradient(
        left,
        #7308c3,
        #c73de9
      ); /* Safari 5.1 - 6.0 */
      background: -o-linear-gradient(
        right,
        #7308c3,
        #c73de9
      ); /* Opera 11.1 - 12.0 */
      background: -moz-linear-gradient(
        right,
        #7308c3,
        #c73de9
      ); /* Firefox 3.6 - 15 */
      background: linear-gradient(to right, #7308c3, #c73de9); /* 标准的语法 */
    }
  }
  .border{
    border: 2.5px solid #fff;
  }
  .circle {
    position: absolute;
    left: 0;
    top: 0;
    border-radius: 50%;
    // border: 6px solid #ff2727;
    width: 100%;
    height: 100%;
    overflow: hidden;
    display: block;
    background: #ff2727;
    // opacity: 0.3;
    // right: 0.75rem;
    // text-align: center;
    // top: 3.18rem;
    // width: calc(100% - 6px);
    // height: calc(100% - 6px);
    // border-color:#ff2727; 
    &:nth-child(1) {
      animation: circle-opacity 0.6s linear infinite;
      -webkit-animation: circle-opacity 0.6s linear infinite;
      -moz-animation: circle-opacity 0.6s linear infinite;
      -o-animation: circle-opacity 0.6s linear infinite;
      -ms-animation: circle-opacity 0.6s linear infinite;
    }
    &:nth-child(2) {
      animation: circle-opacity 0.6s linear infinite;
      -webkit-animation: circle-opacity 0.6s linear infinite;
      -moz-animation: circle-opacity 0.6s linear infinite;
      -o-animation: circle-opacity 0.6s linear infinite;
      -ms-animation: circle-opacity 0.6s linear infinite;
      animation-delay: 0.9s;
      -webkit-animation-delay: 0.9s;
      -o-animation-delay: 0.9s;
      -moz-animation-delay: 0.9s;
      -ms-animation-delay: 0.9s;
    }
    &:nth-child(3) {
      animation: circle-opacity 0.6s linear infinite;
      -webkit-animation: circle-opacity 0.6s linear infinite;
      -moz-animation: circle-opacity 0.6s linear infinite;
      -o-animation: circle-opacity 0.6s linear infinite;
      -ms-animation: circle-opacity 0.6s linear infinite;
      animation-delay: 0.6s;
      -webkit-animation-delay: 0.6s;
      -o-animation-delay: 0.6s;
      -moz-animation-delay: 0.6s;
      -ms-animation-delay: 0.6s;
    }

    @keyframes circle-opacity {
      from {
        border: 1.5px solid #ff2727;
        opacity: 0.6;
        -webkit-transform: scale(1.08);
        -o-transform: scale(1.08);
        -moz-transform: scale(1.08);
        -ms-transform: scale(1.08);
        transform: scale(1.08);
        // border-width:5px;
      }
      to {
        border: 1.5px solid #ff2727;
        opacity: 0;
        -webkit-transform: scale(1.3);
        -o-transform: scale(1.3);
        -moz-transform: scale(1.3);
        -ms-transform: scale(1.3);
        transform: scale(1.3);
      }
    }
    @-o-keyframes circle-opacity {
      from  {
        border: 1.5px solid #ff2727;
        opacity: 0.6;
        -webkit-transform: scale(1.08);
        -o-transform: scale(1.08);
        -moz-transform: scale(1.08);
        -ms-transform: scale(1.08);
        transform: scale(1.08);
        // border-width:5px;
      }
     to {
        border: 1.5px solid #ff2727;
        opacity: 0;
        -webkit-transform: scale(1.3);
        -o-transform: scale(1.3);
        -moz-transform: scale(1.3);
        -ms-transform: scale(1.3);
        transform: scale(1.3);
      }
    }
    @-moz-keyframes circle-opacity {
      from  {
        border: 1.5px solid #ff2727;
        opacity: 0.6;
        -webkit-transform: scale(1.08);
        -o-transform: scale(1.08);
        -moz-transform: scale(1.08);
        -ms-transform: scale(1.08);
        transform: scale(1.08);
        // border-width:5px;
      }
      to {
        border: 1.5px solid #ff2727;
        opacity: 0;
        -webkit-transform: scale(1.3);
        -o-transform: scale(1.3);
        -moz-transform: scale(1.3);
        -ms-transform: scale(1.3);
        transform: scale(1.3);
      }
    }
    @-webkit-keyframes circle-opacity {
      from {
        border: 1.5px solid #ff2727;
        opacity: 0.6;
        -webkit-transform: scale(1.08);
        -o-transform: scale(1.08);
        -moz-transform: scale(1.08);
        -ms-transform: scale(1.08);
        transform: scale(1.08);
        // border-width:5px;
      }
      to {
        border: 1.5px solid #ff2727;
        opacity: 0;
        -webkit-transform: scale(1.3);
        -o-transform: scale(1.3);
        -moz-transform: scale(1.3);
        -ms-transform: scale(1.3);
        transform: scale(1.3);
      }
    }
  }
}
.follow-yi {
  font-size: 0.38rem;
  width: 81.3333%;
  font-weight: bold;
  height: 1.2rem;
  line-height: 1.2rem;
  border-radius: 99px;
  text-align: center;

  // background-color: pink;
  position: fixed;
  bottom: 0.8rem;
  left: 50%;
  transform: translateX(-50%);
  z-index: 10000000;
  color: #fff;
  background: -webkit-linear-gradient(
    90deg,
    rgba(115, 8, 195, 1) 0%,
    rgba(199, 61, 233, 1) 100%
  ); /* Safari 5.1 - 6.0 */
  background: -o-linear-gradient(
    90deg,
    rgba(115, 8, 195, 1) 0%,
    rgba(199, 61, 233, 1) 100%
  ); /* Opera 11.1 - 12.0 */
  background: -moz-linear-gradient(
    90deg,
    rgba(115, 8, 195, 1) 0%,
    rgba(199, 61, 233, 1) 100%
  ); /* Firefox 3.6 - 15 */
  background: linear-gradient(
    90deg,
    rgba(115, 8, 195, 1) 0%,
    rgba(199, 61, 233, 1) 100%
  ); /* 标准的语法 */
  div {
    position: relative;
    margin-left: 5%;
    &:before {
      content: "";
      position: absolute;
      width: 0.35rem;
      height: 0.35rem;
      background: url("../../assets/images/anchorP/follow-1.1_03-min.png")
        no-repeat;
      background-size: contain;
      left: 37%;
      bottom: 0.4rem;
    }
  }
}
.follow-yii {
  font-size: 0.38rem;
  font-weight: bold;
  width: 81.3333%;
  height: 1.2rem;
  line-height: 1.2rem;
  border-radius: 99px;
  text-align: center;
  // background-color: pink;
  position: fixed;
  bottom: 0.8rem;
  left: 50%;
  transform: translateX(-50%);
  z-index: 10000000;
  
  background: -webkit-linear-gradient(
    270deg,
    rgba(245, 245, 245, 1) 0%,
    rgba(238, 238, 238, 1) 100%
  ); /* Safari 5.1 - 6.0 */
  background: -o-linear-gradient(
    270deg,
    rgba(245, 245, 245, 1) 0%,
    rgba(238, 238, 238, 1) 100%
  ); /* Opera 11.1 - 12.0 */
  background: -moz-linear-gradient(
    270deg,
    rgba(245, 245, 245, 1) 0%,
    rgba(238, 238, 238, 1) 100%
  ); /* Firefox 3.6 - 15 */
  background: linear-gradient(
    270deg,
    rgba(245, 245, 245, 1) 0%,
    rgba(238, 238, 238, 1) 100%
  ); /* 标准的语法 */
  div {
    position: relative;
    margin-left: 5%;
    &:before {
      content: "";
      position: absolute;
      width: 0.35rem;
      height: 0.35rem;
      background: url("../../assets/images/anchorP/yiguanzhu@2x-min.png")
        no-repeat;
      background-size: contain;
      left: 37%;
      bottom: 0.35rem;
    }
  }
}
@media screen and (max-width: 320px) {
  .tab_box .record .list_4 ul li .record_1 {
    width: 2.6rem;
  }
  .tab_box .record .list_4 ul li .record_2 {
    margin-right: 1%;
  }
  .tab_box .record .list_4 ul li .record_3 {
    margin-right: 3%;
  }
  .ziliao .list ul .zb_cai div {
    margin-right: 5% !important;
  }
  .list ul .zb_cai div:nth-last-child(1) {
    margin-right: 0 !important;
  }
}
@keyframes circle-opacity {
  0% {
    border: 1.5px solid #ff2727;
    opacity: 0.8;
    -webkit-transform: scale(1.08);
    -o-transform: scale(1.08);
    -moz-transform: scale(1.08);
    -ms-transform: scale(1.08);
    transform: scale(1.08);
    // border-width:5px;
  }
  100% {
    border: 1.5px solid #ff2727;
    opacity: 0;
    -webkit-transform: scale(1.3);
    -o-transform: scale(1.3);
    -moz-transform: scale(1.3);
    -ms-transform: scale(1.3);
    transform: scale(1.3);
  }
}
@-o-keyframes circle-opacity {
  0% {
    border: 1.5px solid #ff2727;
    opacity: 0.8;
    -webkit-transform: scale(1.08);
    -o-transform: scale(1.08);
    -moz-transform: scale(1.08);
    -ms-transform: scale(1.08);
    transform: scale(1.08);
    // border-width:5px;
  }
  100% {
    border: 1.5px solid #ff2727;
    opacity: 0;
    -webkit-transform: scale(1.3);
    -o-transform: scale(1.3);
    -moz-transform: scale(1.3);
    -ms-transform: scale(1.3);
    transform: scale(1.3);
  }
}
@-moz-keyframes circle-opacity {
  0% {
    border: 1.5px solid #ff2727;
    opacity: 0.8;
    -webkit-transform: scale(1.08);
    -o-transform: scale(1.08);
    -moz-transform: scale(1.08);
    -ms-transform: scale(1.08);
    transform: scale(1.08);
    // border-width:5px;
  }
  100% {
    border: 1.5px solid #ff2727;
    opacity: 0;
    -webkit-transform: scale(1.3);
    -o-transform: scale(1.3);
    -moz-transform: scale(1.3);
    -ms-transform: scale(1.3);
    transform: scale(1.3);
  }
}
@-webkit-keyframes circle-opacity {
  0% {
    border: 1.5px solid #ff2727;
    opacity: 0.8;
    -webkit-transform: scale(1.08);
    -o-transform: scale(1.08);
    -moz-transform: scale(1.08);
    -ms-transform: scale(1.08);
    transform: scale(1.08);
    // border-width:5px;
  }
  100% {
    border: 1.5px solid #ff2727;
    opacity: 0;
    -webkit-transform: scale(1.3);
    -o-transform: scale(1.3);
    -moz-transform: scale(1.3);
    -ms-transform: scale(1.3);
    transform: scale(1.3);
  }
}
@-ms-keyframes circle-opacity {
  0% {
    border: 1.5px solid #ff2727;
    opacity: 0.8;
    -webkit-transform: scale(1.08);
    -o-transform: scale(1.08);
    -moz-transform: scale(1.08);
    -ms-transform: scale(1.08);
    transform: scale(1.08);
    // border-width:5px;
  }
  100% {
    border: 1.5px solid #ff2727;
    opacity: 0;
    -webkit-transform: scale(1.3);
    -o-transform: scale(1.3);
    -moz-transform: scale(1.3);
    -ms-transform: scale(1.3);
    transform: scale(1.3);
  }
}
</style>
