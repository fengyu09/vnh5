<template>
  <div class="expert-center">
    <myScroll ref="scrollWrapper" :probeType="2" :top="0" :bottom="0" :left="0" :bgColor="'f5f7fa'">
      <div class="head">
        <div class="headCon">
          <div class="goBack" @click="$router.go(-1)">
            <img src="../../assets/images/white-back-icon.png" alt />
          </div>
          <p class="userName">{{expertData.nickname}}</p>
          <p class="prf">{{expertData.profile}}</p>
        </div>
      </div>
      <div class="userInfo">
        关注
        <span>{{expertData.following}}</span>粉丝
        <span>{{expertData.followers}}</span>获赞
        <span>{{expertData.following}}</span>
        <div class="tx">
          <img v-lazy="expertData.avatar" alt />
          <a>专家</a>
        </div>
      </div>
      <ul class="near">
        <li class="firstLi">
          <!-- <a>近十日</a> -->
          <span class="txt">胜率</span>
          <span class="num">
            {{expertData.win_rate_mul_100}}
            <b>%</b>
          </span>
        </li>
        <li class="borLi">
          <i></i>
          <span class="txt">Lợi nhuận (vndk)</span>
          <span class="num">
            {{expertData.profit_rate_mul_100}}
            <b>%</b>
          </span>
        </li>
        <li class="borLi">
          <i></i>
          <span class="txt">连红</span>
          <span class="num">{{expertData.winning}}</span>
        </li>
      </ul>
      <div class="klotterList">
        <div class="listHead">
          <h6 class="fl">
            <i></i>
            {{expertData.lottery_name}}
          </h6>
          <span class="fr">据下次 {{djsTime}}</span>
        </div>
        <ul class="queryListNum">
          <li
            v-for="(item,i) in tabsParam"
            @click="toggleTabs(i)"
            :class="{active:i==nowIndex}"
            :key="i"
          >
            <a>{{item}}</a>
          </li>
          <!-- <li class="active">
          <a>近10期</a>
        </li>
        <li>
          <a>30期</a>
        </li>
        <li>
          <a>50期</a>
        </li>
        <li>
          <a>100期</a>
          </li>-->
        </ul>
        <div class="tableHead">
          <span style="width:27%">期号/时间</span>
          <span style="width:28%">开奖</span>
          <span style="width:31%">推荐号码</span>
          <span style="width:10%">结果</span>
        </div>
        <div class="tableCon">
          <table v-if="!isloading">
            <tr v-for="(item,index) in planHistoryList" :key="index">
              <td style="width:27%;color:#999999;line-height: 0.5rem;">
                {{item.issue}}
                <br />
                {{item.created | filterTime}}
              </td>
              <td style="width:28%">
                <span v-if="item.open_code!=''">{{item.open_code}}</span>
                <span v-if="item.open_code==''">待开奖</span>
              </td>
              <td style="width:31%;line-height: 0.5rem;">
                {{item.method}}
                <br />
                {{item.code}}
              </td>
              <td style="width:10%">
                <span v-if="item.is_right == 0 || item.is_right == 1">无</span>
                <span v-if="item.is_right == 2">输</span>
                <span v-if="item.is_right == 3">赢</span>
              </td>
            </tr>
          </table>
          <p v-if="isloading">Đang nhận...</p>
        </div>
      </div>
    </myScroll>

    <div class="foot" v-if="!isUser">
      <a class="gz" v-if="cur==0" @click="gz()">
        <img src="../../assets/images/anchorP/follow-1.1_03-min.png" alt /> 关注
      </a>
      <a class="ygz" v-if="cur==1" @click="ygz()">
        <img src="../../assets/images/anchorP/yiguanzhu@2x-min.png" alt /> 已关注
      </a>
    </div>
  </div>
</template>

<script>
import myScroll from "../../components/myScroll.vue";
export default {
  name: "expertCenter",
  data() {
    return {
      cur: 0,
      nowIndex: 0,
      limit: 10,
      iscz: "",
      expertData: "",
      planHistoryList: [],
      tabsParam: ["近10期", "30期", "50期", "100期"],
      isloading: false,
      djsTime: "--:--",
      lotterId: "",
      isUser: false
    };
  },
  components: {
    myScroll
  },
  filters: {
    formatDate1(time) {
      let date = new Date(time * 1000);
      let y = date.getFullYear(); // 年
      let M = date.getMonth() + 1;
      M = M < 10 ? "0" + M : M; // 月
      let D = date.getDate();
      D = D < 10 ? "0" + D : D; // 日
      let hh = date.getHours();
      hh = hh < 10 ? "0" + hh : hh; // 时
      let mm = date.getMinutes();
      mm = mm < 10 ? "0" + mm : mm;
      return y + "-" + M + "-" + D + " " + hh + ":" + mm;
    },
    filterTime(time) {
      if (!time) return;
      let t = new Date(time * 1000);
      let h = t.getHours() >= 10 ? t.getHours() : "0" + t.getHours();
      let min = t.getMinutes() >= 10 ? t.getMinutes() : "0" + t.getMinutes();
      return h + ":" + min;
    },
    filterTime1(time) {
      if (!time) return;
      let t = new Date(time * 1000);
      let h = t.getHours() >= 10 ? t.getHours() : "0" + t.getHours();
      let min = t.getMinutes() >= 10 ? t.getMinutes() : "0" + t.getMinutes();
      let hAm = h < 12 ? h + ":" + min + "AM" : h - 12 + ":" + min + "PM";
      return hAm;
    }
  },
  mounted() {
    this.iscz = this.$route.params.id;
  },
  destroyed() {
    if (window.timer1) clearInterval(window.timer1);
  },
  created() {
    this.init();
  },
  methods: {
    init() {
      this.expert();
      this.isUserTr();
    },
    // 判断是否是专家自己
    isUserTr() {
      if (parseInt(this.$route.params.id) == this.$store.state.userinfo.user_id) {
        this.isUser = true;
      }
    },
    // 关注
    gz() {
      if (
        this.$store.state.userinfo.user_id == undefined ||
        this.$store.state.userinfo.user_id == null ||
        this.$store.state.userinfo.user_id == ""
      ) {
        this.$popup({
          title: "我是标题",
          content: "我是内容",
          btnText: "我是按钮",
          click: () => {
            this.isLogin = false;
          }
        });
      } else {
        this.$http
          .post("/forum/plan/follow", {
            expert_id: this.$route.params.id,
            user_id: this.$store.state.userinfo.user_id
          })
          .then(res => {
            if (res.data.code == 1) {
              this.cur = 1;
              this.expertData.followers += 1;
              this.$vux.toast.show({
                text: "关注成功",
                position: "middle"
              });
              this.expert();
            } else {
            }
          });
      }
    },
    // 取消关注
    ygz() {
      this.$http
        .post("/forum/plan/follow", {
          expert_id: this.$route.params.id,
          user_id: this.$store.state.userinfo.user_id
        })
        .then(res => {
          if (res.data.code == 1) {
            this.cur = 0;
            this.expertData.followers -= 1;
            this.$vux.toast.show({
              text: "取消关注成功",
              position: "middle"
            });
            this.expert();
          } else {
          }
        });
    },
    // 查询历史开奖
    toggleTabs: function(i) {
      this.nowIndex = i;
      this.planhistory(i);
    },
    // 专家个人资料
    expert() {
       let lottery_id = this.$route.fullPath.split("?")[1];
      this.$http
        .get("/forum/plan/expert", {
          params: {
            expert_id: this.$route.params.id,
            user_id: this.$store.state.userinfo.user_id,
            lottery_id:lottery_id
          }
        })
        .then(res => {
          if (res.data.code == 1) {
            this.expertData = res.data.data;
             this.lotterId = res.data.data.lottery_id;
              this.planhistory();
              this.getOneNumber(this.lotterId);
            if (res.data.data.is_followed == 0) {
              this.cur = 0;
            } else {
              this.cur = 1;
            }
          } else {
          }
        });
    },
    planhistory(i, val) {
      let lotterId = val;
      this.limit = 10;
      if (i == 0) {
        this.limit = 10;
      } else if (i == 1) {
        this.limit = 30;
      } else if (i == 2) {
        this.limit = 50;
      } else if (i == 3) {
        this.limit = 100;
      }
      this.isloading = true;
      this.$http
        .get("/forum/plan/history", {
          params: {
            expert_id: this.$route.params.id,
            lottery_id: this.lotterId,
            issue: "",
            limit: this.limit,
            page: 1
          }
        })
        .then(res => {
          if (res.data.code == 1) {
            this.planHistoryList = res.data.data;
            this.isloading = false;
          } else {
          }
        });
    },
    //获取当前开奖信息
    getOneNumber(id, flag) {
    
      this.$http
        .post("/open/idx/indexNewOne", {
          lottery_id: this.lotterId
        })
        .then(res => {
          if (res.data.code == 1) {
            this.timer(res.data.data.next_lottery_time);
          } else {
          }
        });
    },

    timer(t) {
      if (window.timer1) clearInterval(window.timer1);
      window.timer1 = setInterval(() => {
        this.djsTime = this.count(t--);
        if (t <= -1) {
          //          console.log(23)
          this.getOneNumber(null, true);
          this.djsTime = "--:--";
        }
        //        console.log(t)
      }, 1000);
    },
    count(time) {
      let t = "";
      let h = "";
      let d = "";
      let min = "";
      let second = "";
      let obj = {};
      if (time > 60) {
        second = parseInt(time) % 60;
        min = parseInt((time / 60) % 60);
        h = parseInt((parseInt(time / 60) / 60) % 24);
        d = parseInt(parseInt(time / 60) / 60 / 24);
        second = second >= 10 ? second : "0" + second;
        min = min >= 10 ? min : "0" + min;
        if (!h) h = "";
        // else h = h >= 10 ? h : "0" + h + ":";
        else h = h >= 10 ? h : "0" + h ;
        if (d >= 1) {
          t = d + "天" + h + ":" + min + ":" + second;
          // console.log(t);
        } else {
         
          if(h>=1){
               t = h + ":"  + min + ":" + second;
          } else{
             t =  min + ":" + second;
          }
        }
        //              obj ={
        //                h1 :(h+'').split('')[0],
        //                h2 : (h+'').split('')[1],
        //                min1 : (min+'').split('')[0],
        //                min2 :(min+'').split('')[1],
        //                s1 : (second+'').split('')[0],
        //                s2 : (second+'').split('')[1],
        //              }
      } else {
        t = "00:" + (time >= 10 ? time : "0" + time);
        //              t=(time>=10?time:'0'+time);
        //              obj ={
        //                min1 : 0,
        //                min2 :0,
        //                s1 : (time+'').split('')[0],
        //                s2 : (time+'').split('')[1],
        //              }
      }
      //            return obj
      return t;
    },
  }
};
</script>

<style scoped lang="less">
.expert-center {
  background: #f5f7fa;
}
.head {
  width: 100%;
  height: 4rem;
  background: #fff;
  .headCon {
    width: 100%;
    height: 4rem;
    background: url(../../assets/images/anchorP/zjbg.png) no-repeat center;
    background-size: 100% 100%;
    .goBack {
      img {
        width: 0.3rem;
        margin: 0.3rem;
      }
    }
    p {
      color: #fff;
      padding-left: 5.3%;
      clear: both;
    }
    .userName {
      font-size: 0.54rem;
      padding-bottom: 0.15rem;
    }
    .prf {
      font-size: 0.3rem;
    }
  }
}
.userInfo {
  color: #333333;
  font-size: 0.3rem;
  font-family: unset;
  padding-left: 4%;
  background: #fff;
  height: 1.7rem;
  line-height: 1.3rem;
  margin-bottom: 0.5rem;
  span {
    font-size: 0.54rem;
    padding: 0 0.4rem 0 0.12rem;
    font-family: "number1";
  }
  .tx {
    width: 2.5rem;
    height: 2.5rem;
    background: #fff;
    border-radius: 50%;
    position: absolute;
    top: 2.6rem;
    right: 0.5rem;
    text-align: center;
    img {
      width: 2.1rem;
      height: 2.1rem;
      border-radius: 50%;
      margin-top: 0.18rem;
    }
    a {
      position: absolute;
      bottom: 0rem;
      display: block;
      width: 1.2rem;
      line-height: 0.5rem;
      left: 0.7rem;
      color: #fff;
      height: 0.5rem;
      border-radius: 2px 10px 2px 10px;
      background: -webkit-linear-gradient(
        left,
        #0297ff,
        #41e1ef
      ); /* Safari 5.1 - 6.0 */
      background: -o-linear-gradient(
        right,
        #0297ff,
        #41e1ef
      ); /* Opera 11.1 - 12.0 */
      background: -moz-linear-gradient(
        right,
        #0297ff,
        #41e1ef
      ); /* Firefox 3.6 - 15 */
      background: linear-gradient(to right, #0297ff, #41e1ef); /* 标准的语法 */
    }
  }
}

.near {
  height: 3rem;
  background: #fff;
  margin-bottom: 0.5rem;
  li {
    float: left;
    width: 33.33%;
    height: 3rem;
    position: relative;
    span {
      display: block;
      width: 100%;
      text-align: center;
    }
    .txt {
      color: #333333;
      font-size: 0.4rem;
      padding-top: 0.8rem;
      padding-bottom: 0.2rem;
    }
    .num {
      color: #ff513e;
      font-size: 0.6rem;
      font-weight: bold;
      font-family: "number1";
      b {
        font-size: 0.45rem;
        font-family: "number1";
      }
    }
  }
  .borLi i {
    display: block;
    width: 1px;
    height: 1.5rem;
    background: #eee;
    position: absolute;
    top: 0.8rem;
  }
  .firstLi a {
    display: block;
    width: 1.4rem;
    background: #f7f8f9;
    color: #bac0c8;
    padding: 0.1rem 0;
    position: absolute;
    top: 0.25rem;
    left: 0;
    text-align: center;
    border-radius: 0 10px 10px 0;
  }
}

.klotterList {
  background: #fff;
  padding-top: 0.4rem;
  .listHead {
    overflow: hidden;
    h6 {
      font-size: 0.42rem;
      padding-left: 4%;
      i {
        display: inline-block;
        width: 0.1rem;
        height: 0.45rem;
        background: #ff513e;
        border-radius: 10px;
        position: relative;
        top: 2px;
        margin-right: 0.2rem;
        padding-top: 0.1rem;
      }
    }
    span {
      display: inline-block;
      background: -webkit-linear-gradient(
        left,
        #ff3232,
        #ff7f66
      ); /* Safari 5.1 - 6.0 */
      background: -o-linear-gradient(
        right,
        #ff3232,
        #ff7f66
      ); /* Opera 11.1 - 12.0 */
      background: -moz-linear-gradient(
        right,
        #ff3232,
        #ff7f66
      ); /* Firefox 3.6 - 15 */
      background: linear-gradient(to right, #ff3232, #ff7f66); /* 标准的语法 */
      color: #fff;
      padding: 0.15rem 0.4rem;
      border-radius: 20px 0 0 20px;
      font-size: 0.35rem;
      font-family: "number1";
    }
  }
  .queryListNum {
    clear: both;
    overflow: hidden;
    margin: 0.3rem 5%;
    li {
      float: left;
      width: 25%;
      text-align: center;
      a {
        display: block;
        background: #f5f7fa;
        color: #445779;
        font-size: 0.35rem;
        padding: 0.2rem 0.3rem;
        margin: 0 0.2rem;
        border-radius: 99px;
      }
    }
    .active {
      a {
        display: block;
        background: #ffece8;
        color: #ff513e;
        font-size: 0.35rem;
        padding: 0.2rem 0.3rem;
        margin: 0 0.2rem;
        border-radius: 99px;
        font-weight: bold;
      }
    }
  }
  .tableHead {
    margin: 0 2%;
    height: 1rem;
    background: #f5f7fa;
    border-radius: 6px;
    span {
      display: inline-block;
      text-align: center;
      line-height: 1rem;
      color: #999999;
      font-size: 0.3rem;
    }
  }
  .tableCon {
    margin: 0 2%;
    p {
      text-align: center;
      line-height: 1rem;
      color: #666;
    }
    table {
      width: 100%;
      tr {
        display: block;
        width: 100%;
        border-bottom: dashed 1px #eee;
        height: 1.3rem;
        td {
          display: inline-block;
          text-align: center;
          color: #333333;
          font-size: 0.3rem;
          line-height: 1.3rem;
        }
      }
    }
  }
}
.foot {
  width: 100%;
  position: fixed;
  bottom: 11px;
  z-index: 1;
  // background: #fff;
  .gz {
    display: block;
    width: 80%;
    height: 1.3rem;
    text-align: center;
    background: -webkit-linear-gradient(
      left,
      #0096ff,
      #42e2ef
    ); /* Safari 5.1 - 6.0 */
    background: -o-linear-gradient(
      right,
      #0096ff,
      #42e2ef
    ); /* Opera 11.1 - 12.0 */
    background: -moz-linear-gradient(
      right,
      #0096ff,
      #42e2ef
    ); /* Firefox 3.6 - 15 */
    background: linear-gradient(to right, #0096ff, #42e2ef); /* 标准的语法 */
    line-height: 1.3rem;
    color: #fff;
    margin: 0.3rem auto 0.3rem;
    font-size: 0.45rem;
    border-radius: 99px;
    font-weight: 700;
    img {
      width: 0.4rem;
      position: relative;
      top: 0.02rem;
    }
  }
  .ygz {
    display: block;
    width: 80%;
    height: 1.3rem;
    text-align: center;
    background: -webkit-linear-gradient(
      left,
      #f5f5f5,
      #eeeeee
    ); /* Safari 5.1 - 6.0 */
    background: -o-linear-gradient(
      right,
      #f5f5f5,
      #eeeeee
    ); /* Opera 11.1 - 12.0 */
    background: -moz-linear-gradient(
      right,
      #f5f5f5,
      #eeeeee
    ); /* Firefox 3.6 - 15 */
    background: linear-gradient(to right, #f5f5f5, #eeeeee); /* 标准的语法 */
    line-height: 1.3rem;
    color: #999999;
    margin: 0.3rem auto 0.3rem;
    font-size: 0.45rem;
    border-radius: 99px;
    font-weight: 700;
    img {
      width: 0.4rem;
      position: relative;
      top: 0.02rem;
    }
  }
}
</style>
