<template>
    <div class="km-recharge">
        <headerOne/>
        <div class="km-content">
            <div class="input-box">
                <div class="input-item km-user" @focusout="inputBlur" @focusin="inputFocus">
                    <span>卡号</span>
                    <input type="text" placeholder="请输入18位数卡号"  oninput="if(value.length>18)value=value.slice(0,18)" v-model="kmZH"/>
                </div>
                <div class="input-item km-pwd" @focusout="inputBlur" @focusin="inputFocus">
                    <span>密码</span>
                    <input type="text" placeholder="请输入6位数密码" oninput="if(value.length>6)value=value.slice(0,6)" v-model="kmPass"/>
                </div>
                <p>没有卡密？联系代理充值，购买卡密
                    <!-- <router-link to="/kmRechargeList">购买卡密</router-link> -->
                </p>
            </div>
            <router-link class="main-btn confirm-btn buy-btn" style="display:block" to="/kmRechargeList">购买卡密</router-link>
            <div class="main-btn confirm-btn" @click="ExchangeDiamonds()">确认充值</div>
        </div>
        <!--成功-->
        <div class="km-success" v-show="tcBox">
            <div class="km-successBox">
                <i v-show="cgIMG"><img src="../../assets/images/chenggong_03.png" alt=""></i>
                <i v-show="sbIMG"><img src="../../assets/images/shibai.png" alt=""></i>
                <p>{{tsTxt}}</p>
            </div>
        </div>
        <!--失败-->
    </div>
</template>

<script>
    import headerOne from "../../components/headerOne";
    export default {
        name: "kmRecharge",
        components:{
            headerOne
        },
        data(){
            return{
              tsTxt:'充值成功',
              tcBox:false,
              kmZH:'',//卡密账号
              kmPass:'',//卡密密码
              cgIMG:false,
              sbIMG:false
            }
        },
        created() {
        },
        watch:{
            kmZH: function(n, o) {
                if (n) {
                    this.$nextTick(() => {     
                        let i = n.toString();
                        this.kmZH = i.replace(/[^A-Za-z0-9]/g, "");//只允许字母和数字
            
                    });
                }
            },
            kmPass: function(n, o) {
                if (n) {
                    this.$nextTick(() => {     
                        let i = n.toString();
                        this.kmPass = i.replace(/[^A-Za-z0-9]/g, "");//只允许字母和数字
                
                    });
                }
            },


        },
        methods:{
            inputBlur(e) {
                // 首先，判断触发事件的目标元素是否是input输入框，我们只关注输入框的行为。
                if (e && e.target && e.target.tagName && e.target.tagName.toLowerCase() === 'input'||e && e.target && e.target.tagName && e.target.tagName.toLowerCase() === 'textarea') {
                    // 输入框失去焦点，要把IOS键盘推出页面的滚动部分还原。即将页面滚动到视窗顶部对齐
                    this.timer = setTimeout(() => {
                        window.scrollTo(0,0);
                    }, 0)
                }
            },
            inputFocus(e) {
                // 如果focus，则移除上一个输入框的timer
                if (e && e.target && e.target.tagName && e.target.tagName.toLowerCase() === 'input'||e && e.target && e.target.tagName && e.target.tagName.toLowerCase() === 'textarea') {
                    clearTimeout(this.timer);
                }
            },
            ExchangeDiamonds(){
                if(this.kmZH == '' || this.kmZH.length != 18){
                  this.$vux.toast.text('请输入18位数账号', 'middle')
                }else if(this.kmPass == '' || this.kmPass.length != 6){
                  this.$vux.toast.text('请输入6位数密码', 'middle')
                }else{
                    this.$http.post(this.versionLive2+'Recharge/code_recharge',{
                        code:this.kmZH,
                        pass:this.kmPass
                    }).then(res=>{
                        // 清空输入框
                        this.kmZH = '';
                        this.kmPass = '';
                        if(res && res.data.code == 1 ){
                            this.tcBox = true;
                            this.cgIMG = true;
                            this.sbIMG = false;
                            this.tsTxt = res.data.msg;
                        }else if(res && res.data.code == 0){
                            this.tcBox = true;
                            this.sbIMG = true;
                            this.cgIMG = false;
                            this.tsTxt = res.data.msg;
                        }
                        setInterval(()=>{
                        this.tcBox = false;
                        },2000);
                    })
                }
            }

        }
    }
</script>

<style scoped lang="less">
    .rem(@name,@px){
            @{name}:unit(@px/75,rem)
    }
.km-content{
    .rem(margin-top,56);
    .input-box{
        width: 94.66%;
        margin: 0 auto;
        .input-item{
            .rem(margin-bottom,38);
            background: #f7f7f7;
            border-radius: 5px;
            overflow: hidden;
            .rem(padding-top,28);
            .rem(padding-bottom,28);
            .rem(padding-left,18);
            .rem(padding-right,18);
            span{
                float: left;
                width: 20%;
                text-align: center;
                border-right:1px solid #C9C8C8;
                .rem(font-size,32);
                font-weight: 500;
            }
            input{
                float: left;
                width: 80%;
                .rem(font-size,32);
                .rem(padding-left,36);
                line-height: 21px;
            }
        }
        p{
            .rem(margin-bottom,106);
            // .rem(margin-left,19);
            .rem(padding-left,55);
            .rem(font-size,24);
            color: #666;
            background: url('../../assets/images/extend/buyIcon.png') no-repeat;
            background-size: contain;
            // padding-left: 0.7rem;
            a{color: #F73B3B}
        }
    }
    .confirm-btn{
    }

}
    .km-success{
        position: fixed;
        top: 0;
        left: 0;
        background: rgba(0,0,0,0.3);
        z-index: 1;
        width: 100%;
        height: 100vh;
        
        .km-successBox{
            background-color: #fff;
            width: 61.3333%;
            height: 115px;
            position: fixed;
            left: 50%;
            transform: translateX(-50%);
            top: 50%;
            margin-top: -25%;
            border-radius: 10px;
            i{
                display: block;
                width: 1.08rem;
                height: 1.08rem;
                margin: 0.266666rem auto 0.6666rem;
            }
            p{
                .rem(font-size,32);
                text-align: center;
                font-weight: bold;
            }
        }
    }
</style>