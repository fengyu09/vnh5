<template>
  <div id="discuss">
    <x-header
      style="background-color:transparent;z-index: 1001;color:#000"
      :left-options="{showBack: false}"
    >
      <span style="color: #000000;">评论</span>
      <i class="black-back"></i>
      <div
        style="position:absolute;width:42px;height:42px;top:0;left:0; z-index: 10000001;"
        @click="goBack()"
      ></div>
    </x-header>
    <!-- :isLoad="isL"
		v-on:func="reLoad"
		:isUp="isUpFlag"
    :isloadUp="isLup"-->
    <myScroll
      ref="scrollWrapper"
      :isUp="isUpFlag"
      :isloadUp="isLup"
      v-on:func="reLoad"
      :isDown="true"
      :isLoad="isL"
      :bottom="1.38"
    >
      <div class="main">
        <div style="padding: 0 0.3rem;">
          <div
            class="head"
            style="display: flex;align-items: center;"
            @click="getInfo1(artInfo.user_id, artInfo.avatar)"
          >
            <img :src="artInfo.avatar" alt style="width: 50px;height: 50px;border-radius: 50%;" />
            <div style="margin-left: 0.25rem;">
              <p style="font-size: 0.37rem;">{{artInfo.nickname}}</p>
              <p style="color: #cccccc;margin-top: 0.1rem;">{{artInfo.create_time | formatDate1}}</p>
            </div>
          </div>
          <div style="font-size: 0.38rem;padding:0.2rem 0;">
            <span>{{artInfo.text}}</span>
          </div>
          <div class="imgbox">
            <!-- <div class="img-item" v-for="(item,index) in artInfo.media" :key="index">
              <img v-lazy="item" preview="99" alt />
            </div> -->
             <div class="img-item" >
              <img v-lazy="artInfo.media" preview="99" alt />
            </div>
          </div>
        </div>
        <div class="cut-box"></div>
        <div class="pl-box">
          <p class="pl-num">
            评论
            <span style="color: #999999;">({{plnum}})</span>
          </p>
          <div class="pl-content" v-for="(item,index) in plList" :key="index">
            <div
              style="width:46px;height:46px"
              @click="getInfo(item.user_id, item.avatar,item.user_type)"
            >
              <img class="pl-tx" :src="item.avatar" alt />
            </div>
            <div class="right-content">
              <p class="pl-name">{{item.nickname}}</p>

              <p class="text1" v-html="item.content"></p>
              <div class="pl-time">
                <span style="color: #ccc;">{{item.created}}</span>
                <div class="huifu" @click="huifu(item.id,item.nickname,item.user_id)">
                  <i class="huifu-icon"></i> 回复
                </div>
                <!-- likesafter -->
                <div :class="{like:true,likesafter:item.is_like}" @click="dolikes(item.id,index)">
                  <i class="like-iocn"></i>
                  {{item.like}}
                </div>
              </div>
              <div class="huifu-box" v-if="item.reply.length">
                <p v-for="(item1,index1) in item.reply">
                  <span class="name" @click="getInfo(item1.user_id, item1.avatar,item1.user_type)">
                    <i class="lz-icon" v-if="artInfo.user_id==item1.user_id">楼主</i>
                    <i class="zb-icon" v-if="item1.user_type==2">主播</i>
                    {{item1.nickname}}
                  </span> <a v-if="item.user_id!=item1.reply_user_id">回复</a>
                  <span
                    class="name"
                    v-if="item.nickname!=item1.reply_nickname"
                    @click="getInfo(item1.reply_user_id, item1.avatar,item1.reply_user_type)"
                  >
                    <i
                      class="lz-icon"
                      v-if="artInfo.user_id==item1.reply_user_id&&item.nickname!=item1.reply_nickname"
                    >楼主</i>
                    <i
                      class="zb-icon"
                      v-if="item1.reply_user_type==2&&item.nickname!=item1.reply_nickname"
                    >主播</i>
                    {{item1.reply_nickname}}
                  </span>：
                  <span
                    class="hf-text"
                    @click="huifu(item1.id,item1.nickname,item1.user_id)"
                    v-html="item1.content"
                  ></span>
                </p>

                <!-- <p><i class="zb-icon">主播</i><span class="name">派大星</span> <span>回复</span> <i class="lz-icon">楼主</i><span class="name">大猫</span>：<span>可以，可以</span></p> -->
              </div>
            </div>
          </div>
          <!-- <div class="pl-content">
					<img :src="artInfo.avatar" alt="" style="width:46px;height: 46px;border-radius: 50%;">
					<div class="right-content">
						<p class="pl-name">罗拉大镁铝</p>
						<p class="text1">六码打遍天下无敌手十中8竟猜已发喜欢老铁看竟猜 {{plText}} </p>
						<div class="pl-time">
							<span style="color: #ccc;">{{artInfo.created | formatDate1}}</span>
							<div class="huifu"><i class="huifu-icon"></i> 回复</div>
							<div class="like"> <i class="like-iocn"></i> 867</div>
						</div>
					</div>
          </div>-->
        </div>
        <p style="text-align: center;padding: 0.3rem 0;" v-if="deadline">我也是有底线的~</p>
      </div>
    </myScroll>
    <div class="pl-input" :style="{bottom:iptBottom}">
      <keep-alive>
        <vme ref="vmeChild" v-show="showEmj" style="bottom: 1.3rem;z-index: 1448;"></vme>
      </keep-alive>
      <div class="input-bg">
        <!-- @keypress="plSubmit" -->
        <!-- <input
          v-model="chatMsgForm.comment_text"
          type="text"
          ref="huiipt"
          id="textInput"
          @focus="iptFocus()"
          placeholder="要对他说点什么吗"
        /> -->
        <x-input title="" v-model="chatMsgForm.comment_text"  placeholder="要对他说点什么吗" type="text" ref="huiipt" id="textInput" @focus="iptFocus()" :show-clear=false></x-input>
        <div class="emoj-icon" @click="emojShow"></div>
      </div>
      <!-- <div>
				<i class="like-iocn"></i><span>867</span>
      </div>-->
      <div class="sendbtn" @click="plSubmit">
        <span>发送</span>
      </div>
    </div>
    <x-dialog v-model="dialogShow" hide-on-blur @on-hide="showEmj=false;hfId='';iptBottom='0'"></x-dialog>
    <div class="successPop" v-if="success">
      <div class="bgPop"></div>
      <div class="content">
        <img src="../../assets/images/fbcg.png" alt />
        <span class="span1">发布成功</span>
        <span class="span2">小姐姐正在努力审核中</span>
      </div>
    </div>
  </div>
</template>
<script>
import myScroll from "../../components/myScroll.vue";
import vme from "../../components/vue-mobile-emoji/vme.vue";
import { mapMutations, mapState } from "vuex";
import { XDialog,XInput,Group } from "vux";
export default {
  name: "discuss",
  components: {
    myScroll,
    XDialog,
    vme,
    XInput,
    Group
  },
  computed: {
    ...mapState(["codeToken", "userinfo", "username", "avatar"])
  },

  data() {
    return {
      success: false,
      artInfo: {},
      plText: "",
      dialogShow: false,
      isLup: false,
      plnum: "",
      plList: [],
      chatMsgForm: {
        comment_text: ""
      },
      showEmj: false,
      hfId: "",
      hfname: "",
      hfperson: "",
      isMore: true,
      isUpFlag: true,
      page: 1,
      deadline: false,
      isL: false,
      iptBottom: 0,
    };
  },
  created() {
    // this.artInfo = JSON.parse(localStorage.getItem("guessInfo"));
    this.artInfo = JSON.parse(localStorage.getItem("zbpl"));
    console.log(this.artInfo);
    this.getplList();
  },
  watch: {
    chatMsgForm: function(n) {
      this.$nextTick(() => {
        this.chatMsgForm.comment_text = n.replace(
          /[\uD83C|\uD83D|\uD83E][\uDC00-\uDFFF][\u200D|\uFE0F]|[\uD83C|\uD83D|\uD83E][\uDC00-\uDFFF]|[0-9|*|#]\uFE0F\u20E3|[0-9|#]\u20E3|[\u203C-\u3299]\uFE0F\u200D|[\u203C-\u3299]\uFE0F|[\u2122-\u2B55]|\u303D|[\A9|\AE]\u3030|\uA9|\uAE|\u3030/gi,
          ""
        );
      });
    },
    'chatMsgForm.comment_text':function (n) {
       this.$nextTick(()=>{
           this.chatMsgForm.comment_text = n.replace(/[\uD83C|\uD83D|\uD83E][\uDC00-\uDFFF][\u200D|\uFE0F]|[\uD83C|\uD83D|\uD83E][\uDC00-\uDFFF]|[0-9|*|#]\uFE0F\u20E3|[0-9|#]\u20E3|[\u203C-\u3299]\uFE0F\u200D|[\u203C-\u3299]\uFE0F|[\u2122-\u2B55]|\u303D|[\A9|\AE]\u3030|\uA9|\uAE|\u3030/ig,'');
       })
    },
  


  },
  mounted() {
    this.$previewRefresh();
  },
  methods: {
    //  getInfo1(id, avatar){      //头部的用户个人页
    //     this.$router.push({ name: "userInfo", query: { id, avatar } });
    //  },

    removeEmoji() {
      this.value = this.value.replace(
        /\ud83d[\udc00-\ude4f\ude80-\udfff]/g,
        ""
      );
    },

    getInfo(id, avatar, type) {
      if (type == 1) {
        this.$router.push({ name: "userInfo", query: { id, avatar } }); //进入用户个人页
      } else if (type == 2) {
        this.$router.push("/anchorProfile/" + id); //进入主播个人页
      } else if (type == 3) {
        this.$router.push("/expertCenter/" + id); //进入专家个人页
      }
    },
    plSubmit(e) {
      if (
        // 判断是否登录如果登录
        this.$store.state.userinfo.user_id == "" ||
        this.$store.state.userinfo.user_id == undefined
      ) {
        // 如果没有登录提示请登录
       this.$popup({
          title: "我是标题",
          content: "我是内容",
          btnText: "我是按钮",
          click: () => {
            this.isLogin = false;
          }
        });
        return;
      }
      if (this.chatMsgForm.comment_text != "") {
        this.success = true;
        this.$refs.huiipt.blur();
        this.dialogShow = false;
        this.showEmj = false;
        this.$vux.loading.show();
        if (this.hfId == "") {
          // this.chatMsgForm.comment_text='';
          this.$http
            .post("/forum/article/publish-comment", {
              article_id: this.artInfo.comment_id,
              user_id: this.userinfo.user_id,
              nickname: this.username,
              content: this.chatMsgForm.comment_text,
              avatar: this.avatar.slice(this.avatar.indexOf("a"))
            })
            .then(res => {
              this.$vux.loading.hide();
              console.log(res);
              if (res.data.code == 1) {
                setTimeout(() => {
                  this.success = false;
                }, 3000);
                // this.$vux.toast.text('评论成功', 'middle')
                // res.data.data.reply=[];
                // res.data.data.avatar=this.avatar;
                // this.plList.push(res.data.data)
                // this.flitImg(this.plList)
                // this.getplList();
                this.chatMsgForm.comment_text = "";
              }
            });
        } else {
          let hfId = this.hfId;
          this.$http
            .post("/forum/article/publish-comment", {
              article_id: this.artInfo.id,
              user_id: this.userinfo.user_id,
              nickname: this.username,
              content: this.chatMsgForm.comment_text,
              reply_id: this.hfId,
              avatar: this.avatar.slice(this.avatar.indexOf("a"))
              // reply_user_id:this.hfperson,
              // reply_nickname:this.hfname
            })
            .then(res => {
              console.log(res);
              this.$vux.loading.hide();
              if (res.data.code == 1) {
                // this.$vux.toast.text("回复成功", "middle");
                setTimeout(() => {
                  this.success = false;
                }, 3000);
                // let fdindex = this.plList.findIndex(i => i.id == hfId);
                // console.log(fdindex);
                // this.plList[fdindex].reply.push({
                //   nickname: this.username,
                //   content: this.chatMsgForm.comment_text
                // });
                // this.flitImg(this.plList);
                // this.getplList();
                this.chatMsgForm.comment_text = "";
              }
            });
        }
      } else {
        this.$vux.toast.text("请输入内容", "middle");
        this.$refs.huiipt.focus();
      }
    },
    huifu(id, name, nameid) {
      if (nameid == this.$store.state.userinfo.user_id) {
        this.$vux.toast.text("请不要给自己回复", "middle");
        return;
      } else {
        this.$refs.huiipt.focus();
        this.dialogShow = true;
        this.hfId = id;
        this.hfname = name;
        this.hfperson = nameid;
      }
    },
    dolikes(i, index) {
      if (
        // 判断是否登录如果登录
        this.$store.state.userinfo.user_id == "" ||
        this.$store.state.userinfo.user_id == undefined
      ) {
        // 如果没有登录提示请登录
       this.$popup({
          title: "我是标题",
          content: "我是内容",
          btnText: "我是按钮",
          click: () => {
            this.isLogin = false;
          }
        });
        return;
      }
      this.$http
        .post("/forum/article/comment-like", {
          comment_id: i.toString(),
          user_id: this.userinfo.user_id
        })
        .then(res => {
          console.log(res);
          if (res.data.code == 1) {
            this.plList[index].like = parseInt(this.plList[index].like) + 1;
          } else if (res.data.code == 0) {
            this.plList[index].like = parseInt(this.plList[index].like) - 1;
          }
          this.plList[index].is_like = !this.plList[index].is_like;
        });
    },
    reLoad(data) {
      console.log(data);
      if (data == "up") {
        this.loadMore();
      } else if (data == "down") {
        this.renovate();
      }
    },
    emojShow() {
      this.showEmj = !this.showEmj;
      this.$refs.huiipt.focus();
    },
    getplList() {
      this.$vux.loading.show();
      this.$http
        .get("/forum/article/comment", {
          params: {
            limit: 10,
            page: 1,
            article_id: this.artInfo.comment_id,
            user_id: this.userinfo.user_id
          }
        })
        .then(res => {
          this.$vux.loading.hide();
          // console.log(res.data.data);
          if (res.data.code == 1) {
            this.plnum = res.data.total;
            this.plList = res.data.data;
            this.flitImg(res.data.data);
          }
        });
    },
    renovate() {
      this.isL = true;
      this.$http
        .get("/forum/article/comment", {
          params: {
            limit: 10,
            page: 1,
            article_id: this.artInfo.comment_id
          }
        })
        .then(res => {
          console.log(res.data.data);
          this.isL = false;
          this.page = 1;
          this.isUpFlag = true;
          this.deadline = false;
          this.plnum = res.data.total;
          this.plList = res.data.data;
          this.flitImg(res.data.data);
        });
    },
      flitImg(data) {
      let len = this.$refs.vmeChild.emojis.length;
      let fhbq = this.$refs.vmeChild.fhbqList;
      let dL = data.length;
      for (let o = 0; o < dL; o++) {
        for (let i = 0; i < len; i++) {
          if (data[o].content.indexOf(this.$refs.vmeChild.emojis[i]) > -1) {
            let len = data[o].content.length;
            for (let j = 0; j < len; j++) {
              this.plList[o].content = this.plList[o].content.replace(
                this.$refs.vmeChild.emojis[i],
                '<img src="../static/images/chat/emoji/' +
                  this.$refs.vmeChild._emojiName(
                    this.$refs.vmeChild.emojis[i]
                  ) +
                  '">'
              );
            }
          }
          if (data[o].reply.length) {
            for (let y = 0; y < data[o].reply.length; y++) {
              if (data[o].reply[y].content.indexOf(this.$refs.vmeChild.emojis[i]) > -1) {
                let len = data[o].reply[y].content.length;
                for (let j = 0; j < len; j++) {
                  this.plList[o].reply[y].content = this.plList[o].reply[y].content.replace(
                    this.$refs.vmeChild.emojis[i],
                    '<img src="../static/images/chat/emoji/' +
                      this.$refs.vmeChild._emojiName(
                        this.$refs.vmeChild.emojis[i]
                      ) +
                      '">'
                  );
                }
              }

              fhbq.forEach((item, i) => {
                // if (data[o].type == "publish") {
                if (data[o].reply[y].content.indexOf(item.flag) > -1) {
                  let len = data[o].reply[y].content.length
                  for (let j = 0; j < len; j++) {
                    this.plList[o].reply[y].content = this.plList[o].reply[y].content.replace(
                      item.flag,
                      '<img src="' +
                        item.imgSrc +
                        '" style="width:0.4rem;vertical-align: text-bottom;">'
                    );
                  }
                }
                // }
              });
            }
          }
        }

        fhbq.forEach((item, i) => {
          // if (data[o].type == "publish") {
          if (data[o].content.indexOf(item.flag) > -1) {
            let len = data[o].content.length;
            for (let j = 0; j < len; j++) {
              this.plList[o].content = this.plList[o].content.replace(
                item.flag,
                '<img src="' +
                  item.imgSrc +
                  '" style="width:0.4rem;vertical-align: text-bottom;">'
              );
            }
          }
          // }
        });
      }
    },
    flitText(t) {
      console.log(t);
      let len = this.$refs.vmeChild.emojis.length;
      let text = t;
      for (let i = 0; i < len; i++) {
        if (t.indexOf(this.$refs.vmeChild.emojis[i]) > -1) {
          let len2 = t.length;
          for (let j = 0; j < len2; j++) {
            console.log(111);
            text = t.replace(
              this.$refs.vmeChild.emojis[i],
              '<img src="../static/images/chat/emoji/' +
                this.$refs.vmeChild._emojiName(this.$refs.vmeChild.emojis[i]) +
                '">'
            );
          }
        }
      }

      return text;
    },
    loadMore() {
      this.isLup = true;
      this.page++;
      this.$http
        .get("/forum/article/comment", {
          params: {
            limit: 10,
            page: this.page,
            article_id: this.artInfo.id
          }
        })
        .then(res => {
          this.isLup = false;
          if (res.data.data.length < 1) {
            this.isUpFlag = false;
            this.deadline = true;
          }
          // this.plnum = res.data.total
          this.plList = this.plList.concat(
            res.data.data.filter(i => {
              return i.content != undefined;
            })
          );
          // console.log(res.data.data.filter(i=>{return i.content!=undefined}))
          this.flitImg(this.plList);
          setTimeout(() => {
            this.$refs.scrollWrapper.refresh(); //重新计算高度，刷新滚动条
          }, 20);
        });
    },
    goBack() {
      if (this.$route.query.mode) {
        this.$router.push({
          name: "guess",
          query: { mode: this.$route.query.mode }
        });
      } else {
        this.$router.go(-1);
      }
    },
    iptFocus() {
      this.dialogShow = true;
      if (navigator.userAgent.includes("MiuiBrowser")) {
        this.iptBottom = "0.72rem";
      }
    }
  }
};
</script>
<style lang="less">
.vux-header .vux-header-title {
  color: #000;
}

.black-back {
  display: block;
  width: 12px;
  height: 20px;
  position: absolute;
  background: #ccc;
  top: 12px;
  left: 12px;
  background: url("../../assets/images/withdrawals/fanhui.png") no-repeat;
  background-size: 100% 100%;
}

#discuss {
  .main {
    .imgbox {
      display: flex;
      flex-wrap: wrap;

      .img-item {
        width: 2.933rem;
        height: 2.933rem;
        border-radius: 0.2rem;
        overflow: hidden;
        margin: 0 0.1rem;
        margin-bottom: 0.2rem;

        img {
          width: 100%;
          pointer-events: unset;
          min-height: 2.933rem;
        }
      }
    }

    .cut-box {
      height: 0.29rem;
      background: #f5f7fa;
      margin: 0.2rem 0;
    }

    .pl-box {
      padding: 0 0.3rem;

      .pl-num {
        font-size: 0.38rem;
        margin-bottom: 0.3rem;
      }

      .pl-content {
        display: flex;
        .pl-tx {
          width: 46px;
          height: 46px;
          border-radius: 50%;
        }
        .right-content {
          margin-left: 0.2rem;
          width: 100%;
        }

        .pl-name {
          font-size: 0.36rem;
          color: #999999;
          margin: 0.1rem 0 0.1rem 0;
        }

        .text1 {
          font-size: 0.38rem;
          width: 7.5rem;
          word-wrap: break-word;
          img {
            width: 0.44rem;
            vertical-align: text-bottom;
          }
        }

        .pl-time {
          display: flex;
          justify-content: space-between;
          margin: 0.36rem 0;

          .huifu {
            margin-right: -2.4rem;

            .huifu-icon {
              display: inline-block;
              width: 0.42rem;
              height: 0.42rem;
              background: url("../../assets/images/guess/pl-icon.png") no-repeat;
              background-size: 100% 100%;
              float: left;
              margin-right: 0.06rem;
            }
          }

          .like {
            .like-iocn {
              display: inline-block;
              width: 0.54rem;
              height: 0.39rem;
              background: url(../../assets/images/allIcon.png);
              background-position: 0 3.64rem;
              background-size: 1.13rem;
              float: left;
            }
          }

          .likesafter {
            .like-iocn {
              display: inline-block;
              width: 0.54rem;
              position: relative;
              height: 0.39rem;
              background: url(../../assets/images/allIcon.png);
              background-position: 0 3.24rem;
              background-size: 1.13rem;
            }
          }
        }

        .huifu-box {
          padding: 0.36rem;
          background: #f5f7fa;
          border-radius: 0.15rem;

          p {
            font-size: 0.36rem;
            padding-bottom: 0.2rem;
            .hf-text {
              img {
                width: 0.4rem;
                vertical-align: text-bottom;
              }
            }
            i {
              display: inline-block;
              padding: 0.04rem 0.1rem;
              font-size: 0.3rem;
              margin-right: 0.1rem;
            }

            .lz-icon {
              background: #e2ecf7;
              border-radius: 4px;
              color: #1a88ff;
            }

            .zb-icon {
              background: #ede5f9;
              border-radius: 4px;
              color: #d444f3;
            }

            .name {
              color: #5f84b0;
              margin-right: 0.08rem;
            }
          }
        }

        .huifu-box p:last-child {
          padding: 0;
        }

        .right-content {
          border-bottom: 1px solid #eeeeee;
          padding-bottom: 0.5rem;
          margin-bottom: 0.3rem;
        }
      }

      .pl-content:last-child .right-content {
        border: none;
        margin-bottom: 0;
      }
    }
  }

  .pl-input {
    position: absolute;
    width: 100%;
    padding: 0.2rem 0.3rem;
    bottom: 0;
    display: flex;
    align-items: center;
    color: #999999;
    justify-content: space-between;
    border-top: 1px solid #eeeeee;
    z-index: 1499;
    background: #fff;

    .input-bg {
      width: 76%;
      height: 0.93rem;
      background: #f5f7fa;
      border-radius: 0.5rem;

      input {
        width: 86%;
        height: 100%;
        padding-left: 0.4rem;
      }

      .emoj-icon {
        width: 0.58rem;
        height: 0.58rem;
        background: url("../../assets/images/chat/em.png") no-repeat;
        background-size: 100% 100%;
        position: absolute;
        top: 0.38rem;
        right: 3rem;
      }
    }

    .like-iocn {
      display: inline-block;
      width: 0.54rem;
      height: 0.39rem;
      background: url(../../assets/images/allIcon.png);
      background-position: 0 3.64rem;
      background-size: 1.13rem;
      float: left;
    }
    .sendbtn {
      height: 0.82rem;
      width: 20%;
      background: #ff513e;
      border-radius: 0.5rem;
      text-align: center;
      line-height: 0.82rem;
      font-size: 0.38rem;
      color: #fff;
      background-image: linear-gradient(to right, #ff3433, #ff7e66);
    }
  }
}

.successPop {
  position: fixed;
  z-index: 10001;
  width: 100%;
  height: 100%;
  .bgPop {
    background: rgba(0, 0, 0, 0.5);
    width: 100%;
    height: 100%;
  }
  .content {
    width: 45%;
    margin: 0 28%;
    z-index: 10002;
    background: #fff;
    text-align: center;
    position: absolute;
    top: 22%;
    padding: 0.6rem 0;
    border-radius: 5px;
    img {
      width: 1.3rem;
    }
    span {
      display: block;
    }
    .span1 {
      font-weight: 600;
      padding-top: 0.3rem;
      color: #000000;
      font-size: 0.4rem;
    }
    .span2 {
      padding-top: 0.1rem;
      color: #999999;
      font-size: 0.3rem;
    }
  }
}

.lz-icon {
  background: #e2ecf7;
  border-radius: 3px;
  color: #1a88ff;
  padding: 1px 4px;
  font-size: 0.3rem;
}

.zb-icon {
  background: #ede5f9;
  border-radius: 3px;
  color: #d444f3;
  padding: 1px 4px;
  font-size: 0.3rem;
}
</style>
